package com.kos.notifycontrol.data.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import androidx.core.content.ContextCompat
import com.kos.notifycontrol.domain.repository.LocationRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/** Reads the device location switch. No location permission is needed for this (it is not the user's position). */
@Singleton
class SystemLocationRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : LocationRepository {
    private val lm = context.getSystemService(LocationManager::class.java)

    override fun read(): Boolean? = try {
        lm.isLocationEnabled
    } catch (e: RuntimeException) {
        null
    }

    override val changes: Flow<Unit> = callbackFlow<Unit> {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) { trySend(Unit) }
        }
        ContextCompat.registerReceiver(
            context, receiver, IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        awaitClose { context.unregisterReceiver(receiver) }
    }
}
