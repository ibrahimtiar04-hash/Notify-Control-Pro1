package com.kos.notifycontrol.domain.repository

import com.kos.notifycontrol.domain.model.AccentColor
import com.kos.notifycontrol.domain.model.Customization
import com.kos.notifycontrol.domain.model.TileSlot
import kotlinx.coroutines.flow.Flow

interface LocationRepository {
    /** Whether the device location switch is on; null when the system could not tell. */
    fun read(): Boolean?
    val changes: Flow<Unit>
}

interface CustomizationRepository {
    val customization: Flow<Customization>
    suspend fun setAccent(accent: AccentColor)
    suspend fun setPanelAlpha(alpha: Float)
    suspend fun setSlots(slots: List<TileSlot>)
    suspend fun reset()
}

interface NotificationAccess {
    /** True when the user enabled this app under "Notification access" in system settings. */
    fun isEnabled(): Boolean
}
