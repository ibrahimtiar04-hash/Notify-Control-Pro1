package com.kos.notifycontrol.domain.model

import java.time.ZonedDateTime

enum class TileId { WIFI, BLUETOOTH, FLASHLIGHT, LOCATION, AIRPLANE, DND, AUTO_ROTATE }

/** UNKNOWN = the system gave no usable value; UNAVAILABLE = absent on this device or in use; never shown as OFF. */
enum class TileStatus { ON, OFF, UNKNOWN, UNAVAILABLE, PERMISSION_REQUIRED }

data class TileState(val id: TileId, val status: TileStatus)

/** System screens a tile can open when Android does not allow changing the setting directly. */
enum class SystemScreen {
    WIFI_PANEL, BLUETOOTH_SETTINGS, LOCATION_SETTINGS, AIRPLANE_SETTINGS, DND_ACCESS,
    WRITE_SETTINGS, OVERLAY_PERMISSION, APP_DETAILS
}

sealed interface TileEffect {
    data object None : TileEffect
    data class Launch(val screen: SystemScreen) : TileEffect
    /** Only produced when the host can show system dialogs (the app screen, not the overlay). */
    data object RequestBluetoothEnable : TileEffect
    data object RequestBluetoothPermission : TileEffect
    data class Rejected(val error: ActionError) : TileEffect
}

data class ControlCenterState(
    val tiles: List<TileState>,
    val brightness: Int?,
    val autoBrightness: Boolean?,
    val canWriteSettings: Boolean,
    val volumes: List<VolumeState>,
    val volumeAvailability: VolumeAvailability,
    val battery: BatteryState?,
    val now: ZonedDateTime?,
    val accent: AccentColor,
    val panelAlpha: Float,
    val error: ActionError?
)
