package com.kos.notifycontrol.data.system

import android.app.ActivityOptions
import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.RequestResult
import com.kos.notifycontrol.domain.notifications.NotificationActions
import com.kos.notifycontrol.domain.notifications.NotificationFilter
import com.kos.notifycontrol.domain.notifications.NotificationItem
import com.kos.notifycontrol.domain.notifications.NotificationStore
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Real notification access. It only works after the user enables this app under "Notification access"
 * in system settings. Notification content is kept in memory only and is never logged or sent anywhere.
 */
@AndroidEntryPoint
class NotifyListenerService : NotificationListenerService(), NotificationActions {
    @Inject lateinit var store: NotificationStore

    override fun onListenerConnected() {
        val active = try { activeNotifications?.toList() ?: emptyList() } catch (e: RuntimeException) { emptyList() }
        store.onConnected(active.mapNotNull(::toItem), this)
    }

    override fun onListenerDisconnected() = store.onDisconnected()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        toItem(sbn)?.let(store::onPosted)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) = store.onRemoved(sbn.key)

    override fun onDestroy() {
        store.onDisconnected()
        super.onDestroy()
    }

    private fun toItem(sbn: StatusBarNotification): NotificationItem? {
        val n = sbn.notification
        val isSummary = n.flags and Notification.FLAG_GROUP_SUMMARY != 0
        if (!NotificationFilter.shouldShow(sbn.packageName, packageName, isSummary)) return null
        val extras = n.extras
        return NotificationItem(
            key = sbn.key,
            packageName = sbn.packageName,
            appName = appLabel(sbn.packageName),
            title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
            text = (extras?.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras?.getCharSequence(Notification.EXTRA_TEXT))?.toString(),
            postTime = sbn.postTime,
            isOngoing = sbn.isOngoing,
            isClearable = sbn.isClearable
        )
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }

    // ---------------- NotificationActions ----------------
    override fun open(key: String): RequestResult {
        val sbn = try { getActiveNotifications(arrayOf(key))?.firstOrNull() } catch (e: RuntimeException) { null }
            ?: return RequestResult.Rejected(ActionError.FAILED)
        val pi = sbn.notification.contentIntent
        if (pi != null) {
            try {
                send(pi)
                return RequestResult.Accepted
            } catch (e: PendingIntent.CanceledException) {
                // fall through: open the app itself
            } catch (e: RuntimeException) {
                // fall through
            }
        }
        return launchApp(sbn.packageName)
    }

    private fun send(pi: PendingIntent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val options = ActivityOptions.makeBasic()
                .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
            pi.send(this, 0, null, null, null, null, options.toBundle())
        } else {
            pi.send()
        }
    }

    private fun launchApp(pkg: String): RequestResult {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return RequestResult.Rejected(ActionError.UNSUPPORTED)
        return try {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            RequestResult.Accepted
        } catch (e: RuntimeException) {
            RequestResult.Rejected(ActionError.FAILED)
        }
    }

    override fun dismiss(key: String): RequestResult = try {
        cancelNotification(key)
        RequestResult.Accepted // the list updates from onNotificationRemoved
    } catch (e: SecurityException) {
        RequestResult.Rejected(ActionError.PERMISSION_REQUIRED)
    } catch (e: RuntimeException) {
        RequestResult.Rejected(ActionError.FAILED)
    }

    override fun dismissAll(): RequestResult = try {
        cancelAllNotifications() // clears only what Android allows (not ongoing ones)
        RequestResult.Accepted
    } catch (e: SecurityException) {
        RequestResult.Rejected(ActionError.PERMISSION_REQUIRED)
    } catch (e: RuntimeException) {
        RequestResult.Rejected(ActionError.FAILED)
    }
}
