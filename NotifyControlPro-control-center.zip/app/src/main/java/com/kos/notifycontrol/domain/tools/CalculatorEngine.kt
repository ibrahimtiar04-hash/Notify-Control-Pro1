package com.kos.notifycontrol.domain.tools

import java.math.BigDecimal
import java.math.MathContext

sealed interface CalcResult {
    data class Value(val text: String) : CalcResult
    data class Error(val reason: CalcError) : CalcResult
}

enum class CalcError { DIVISION_BY_ZERO, SYNTAX }

/** Exact decimal arithmetic. Supports + - × ÷ % (percent = /100), unary minus and parentheses. */
object CalculatorEngine {
    private class Fail(val reason: CalcError) : Exception()

    fun evaluate(expression: String): CalcResult = try {
        val v = Parser(expression).parse()
        CalcResult.Value(v.stripTrailingZeros().toPlainString())
    } catch (f: Fail) {
        CalcResult.Error(f.reason)
    } catch (e: NumberFormatException) {
        CalcResult.Error(CalcError.SYNTAX)
    }

    private class Parser(private val s: String) {
        private var i = 0

        fun parse(): BigDecimal {
            if (s.isEmpty()) throw Fail(CalcError.SYNTAX)
            val v = expr()
            if (i != s.length) throw Fail(CalcError.SYNTAX)
            return v
        }

        private fun expr(): BigDecimal {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v.add(r) else v.subtract(r)
            }
            return v
        }

        private fun term(): BigDecimal {
            var v = unary()
            while (i < s.length && (s[i] == '×' || s[i] == '÷')) {
                val op = s[i++]
                val r = unary()
                v = if (op == '×') v.multiply(r) else {
                    if (r.signum() == 0) throw Fail(CalcError.DIVISION_BY_ZERO)
                    v.divide(r, MathContext.DECIMAL64)
                }
            }
            return v
        }

        private fun unary(): BigDecimal {
            if (i < s.length && s[i] == '-') { i++; return unary().negate() }
            return postfix()
        }

        private fun postfix(): BigDecimal {
            var v = primary()
            while (i < s.length && s[i] == '%') { i++; v = v.divide(BigDecimal(100)) }
            return v
        }

        private fun primary(): BigDecimal {
            if (i >= s.length) throw Fail(CalcError.SYNTAX)
            if (s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw Fail(CalcError.SYNTAX)
                i++
                return v
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw Fail(CalcError.SYNTAX)
            val text = s.substring(start, i)
            if (text.count { it == '.' } > 1 || text == ".") throw Fail(CalcError.SYNTAX)
            return BigDecimal(text)
        }
    }
}
