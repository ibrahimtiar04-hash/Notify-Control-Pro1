package com.kos.notifycontrol.features.controlcenter

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ControlCenterViewModel @Inject constructor(factory: ControlCenterControllerFactory) : ViewModel() {
    val controller = factory.create(viewModelScope, supportsDialogs = true)
    val state = controller.state

    override fun onCleared() = controller.stop()
}
