package com.kos.notifycontrol.domain.tools

import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

interface TimerStore {
    val endAt: Flow<Long?>
    /** May throw IOException. */
    suspend fun load(): Long?
    suspend fun save(endAt: Long)
    suspend fun clear()
}

interface TimerAlarm {
    /** May throw SecurityException. */
    fun schedule(endAt: Long)
    /** Cancels the pending alarm and any posted timer notification. */
    fun cancel()
}

/**
 * Serializes every operation that changes the timer (start / cancel / restore) behind one lock, and always
 * reads the saved state INSIDE the lock. So a restore that is in flight can never re-arm an alarm after a cancel:
 * either cancel runs first (restore then finds nothing saved) or restore runs first (cancel then removes its alarm).
 * Platform-free so the interleavings can be unit-tested.
 */
class TimerCoordinator(
    private val store: TimerStore,
    private val alarm: TimerAlarm,
    private val now: () -> Long
) {
    private val lock = Mutex()

    /** End time the user cancelled but that could not be erased from storage (this process only). */
    private var tombstone: Long? = null

    val endAtMillis: Flow<Long?> get() = store.endAt

    /** Replaces any existing timer. On failure no timer is left running. */
    suspend fun start(durationMs: Long): ActionResult = lock.withLock {
        tombstone = null
        val endAt = now() + durationMs
        try {
            alarm.schedule(endAt)
            store.save(endAt)
            ActionResult.Success(0)
        } catch (e: SecurityException) {
            abandon()
            ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        } catch (e: IOException) {
            abandon()
            ActionResult.Failure(ActionError.FAILED)
        }
    }

    suspend fun cancel(): Unit = lock.withLock<Unit> {
        alarm.cancel()
        val saved = try { store.load() } catch (e: IOException) { null }
        try {
            store.clear()
        } catch (e: IOException) {
            // The saved time could not be erased: make sure restore() in this process never re-arms it.
            tombstone = saved
        }
    }

    suspend fun restore(): Unit = lock.withLock<Unit> {
        try {
            val saved = store.load() ?: return@withLock
            if (saved > now() && saved != tombstone) alarm.schedule(saved)
        } catch (e: IOException) {
            // saved state unreadable: nothing to restore
        } catch (e: SecurityException) {
            // alarm could not be re-armed: the in-app countdown still works
        }
    }

    private suspend fun abandon() {
        alarm.cancel()
        try { store.clear() } catch (e: IOException) { /* best effort */ }
    }
}
