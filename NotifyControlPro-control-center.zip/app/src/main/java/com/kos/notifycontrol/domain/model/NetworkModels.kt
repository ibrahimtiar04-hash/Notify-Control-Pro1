package com.kos.notifycontrol.domain.model

/** PERMISSION_REQUIRED = the system refused the read (SecurityException); UNKNOWN = the system gave no usable value. */
enum class ToggleState { ON, OFF, TURNING_ON, TURNING_OFF, UNKNOWN, PERMISSION_REQUIRED }

/** UNKNOWN = the active network could not be read; it is never reported as NONE in that case. */
enum class ActiveTransport { WIFI, CELLULAR, ETHERNET, OTHER, NONE, UNKNOWN }

/**
 * null = not supported on this device or not readable through public APIs
 * (never replaced with a default value).
 */
data class NetworkSnapshot(
    val wifi: ToggleState?,
    val bluetooth: ToggleState?,
    val airplaneMode: Boolean?,
    val transport: ActiveTransport,
    val internetValidated: Boolean
)
