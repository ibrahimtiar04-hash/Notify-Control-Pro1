package com.kos.notifycontrol.data.system

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import com.kos.notifycontrol.domain.tools.TimerAlarm
import com.kos.notifycontrol.domain.tools.TimerStore
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Singleton
class DataStoreTimerStore @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : TimerStore {
    private val key = longPreferencesKey("timer_end_at")
    override val endAt: Flow<Long?> = dataStore.data.map { it[key] }
    override suspend fun load(): Long? = dataStore.data.first()[key]
    override suspend fun save(endAt: Long) { dataStore.edit { it[key] = endAt } }
    override suspend fun clear() { dataStore.edit { it.remove(key) } }
}

@Singleton
class AlarmManagerTimerAlarm @Inject constructor(
    @ApplicationContext private val context: Context
) : TimerAlarm {
    private val alarms = context.getSystemService(AlarmManager::class.java)

    private fun pendingIntent() = PendingIntent.getBroadcast(
        context, 1, Intent(context, TimerReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    // Inexact-while-idle alarm: needs no special permission; delivery can be delayed in Doze.
    override fun schedule(endAt: Long) {
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pendingIntent())
    }

    override fun cancel() {
        alarms.cancel(pendingIntent())
        TimerNotifier.cancel(context)
    }
}
