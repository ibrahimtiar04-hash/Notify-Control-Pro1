package com.kos.notifycontrol.core.designsystem

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.kos.notifycontrol.R
import com.kos.notifycontrol.domain.model.ActionError

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            content()
        }
    }
}

@Composable
fun LabeledRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ErrorText(error: ActionError?) {
    val text = when (error) {
        null -> return
        ActionError.PERMISSION_REQUIRED -> stringResource(R.string.permission_required)
        ActionError.UNSUPPORTED -> stringResource(R.string.action_unsupported)
        ActionError.FAILED -> stringResource(R.string.action_failed)
    }
    Text(text, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
}

object SettingsIntents {
    fun of(screen: com.kos.notifycontrol.domain.model.SystemScreen, pkg: String): Intent = when (screen) {
        com.kos.notifycontrol.domain.model.SystemScreen.WIFI_PANEL -> wifi()
        com.kos.notifycontrol.domain.model.SystemScreen.BLUETOOTH_SETTINGS -> bluetooth()
        com.kos.notifycontrol.domain.model.SystemScreen.LOCATION_SETTINGS -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        com.kos.notifycontrol.domain.model.SystemScreen.AIRPLANE_SETTINGS -> airplane()
        com.kos.notifycontrol.domain.model.SystemScreen.DND_ACCESS -> dndAccess()
        com.kos.notifycontrol.domain.model.SystemScreen.WRITE_SETTINGS -> writeSettings(pkg)
        com.kos.notifycontrol.domain.model.SystemScreen.OVERLAY_PERMISSION ->
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg"))
        com.kos.notifycontrol.domain.model.SystemScreen.APP_DETAILS -> appDetails(pkg)
    }
    fun notificationListenerAccess() = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
    /** Notification settings of another app (the system page where its channels are managed). */
    fun appNotificationSettings(pkg: String) =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
    fun display() = Intent(Settings.ACTION_DISPLAY_SETTINGS)
    fun wifi() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_WIFI)
        else Intent(Settings.ACTION_WIFI_SETTINGS)
    fun internet() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        else Intent(Settings.ACTION_WIRELESS_SETTINGS)
    fun wireless() = Intent(Settings.ACTION_WIRELESS_SETTINGS)
    fun bluetooth() = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
    fun airplane() = Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
    fun appDetails(pkg: String) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
    fun sound() = Intent(Settings.ACTION_SOUND_SETTINGS)
    fun dndAccess() = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
    fun writeSettings(pkg: String) =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$pkg"))
}

/** Returns false when the device has no screen for this intent. */
fun Context.launchSettings(intent: Intent): Boolean = try {
    startActivity(intent); true
} catch (e: ActivityNotFoundException) {
    false
}
