package com.kos.notifycontrol.navigation

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kos.notifycontrol.R
import com.kos.notifycontrol.features.controlcenter.ControlCenterScreen
import com.kos.notifycontrol.features.customize.CustomizeScreen
import com.kos.notifycontrol.features.notifications.NotificationCenterScreen
import com.kos.notifycontrol.features.settings.SettingsScreen
import com.kos.notifycontrol.features.tools.CalculatorScreen
import com.kos.notifycontrol.features.tools.RecorderScreen
import com.kos.notifycontrol.features.tools.StopwatchScreen
import com.kos.notifycontrol.features.tools.TimerScreen
import com.kos.notifycontrol.features.tools.ToolRoutes
import com.kos.notifycontrol.features.tools.ToolsScreen

enum class Destination(val route: String, @StringRes val label: Int, val icon: ImageVector) {
    Control("control", R.string.nav_control, Icons.Filled.Home),
    Notifications("notifications", R.string.nav_notifications, Icons.Filled.Notifications),
    Tools("tools", R.string.nav_tools, Icons.Filled.Build),
    Customize("customize", R.string.nav_customize, Icons.Filled.Edit),
    Settings("settings", R.string.nav_settings, Icons.Filled.Settings)
}

@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(bottomBar = {
        NavigationBar {
            Destination.entries.forEach { d ->
                NavigationBarItem(
                    selected = current == d.route || (d == Destination.Tools && current?.startsWith("tools/") == true),
                    onClick = {
                        nav.navigate(d.route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true; restoreState = true
                        }
                    },
                    icon = { Icon(d.icon, contentDescription = null) },
                    label = { Text(stringResource(d.label)) }
                )
            }
        }
    }) { pad ->
        val m = Modifier.padding(pad)
        NavHost(nav, startDestination = Destination.Control.route) {
            composable(Destination.Control.route) { ControlCenterScreen(m) }
            composable(Destination.Notifications.route) { NotificationCenterScreen(m) }
            composable(Destination.Tools.route) { ToolsScreen(m, onOpen = { nav.navigate(it) }) }
            composable(Destination.Customize.route) { CustomizeScreen(m) }
            composable(Destination.Settings.route) { SettingsScreen(m) }
            composable(ToolRoutes.CALCULATOR) { CalculatorScreen(m) }
            composable(ToolRoutes.TIMER) { TimerScreen(m) }
            composable(ToolRoutes.STOPWATCH) { StopwatchScreen(m) }
            composable(ToolRoutes.RECORDER) { RecorderScreen(m) }
        }
    }
}
