package com.kos.notifycontrol.domain.notifications

import com.kos.notifycontrol.domain.model.RequestResult
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** One notification as reported by the system. Held in memory only; never persisted or logged. */
data class NotificationItem(
    val key: String,
    val packageName: String,
    val appName: String,
    val title: String?,
    val text: String?,
    val postTime: Long,
    val isOngoing: Boolean,
    val isClearable: Boolean
)

/** Actions the connected listener service can perform. Accepted = request accepted; the list updates from callbacks. */
interface NotificationActions {
    fun open(key: String): RequestResult
    fun dismiss(key: String): RequestResult
    fun dismissAll(): RequestResult
}

object NotificationFilter {
    /** Own notifications (e.g. the floating-panel service) and group summaries are not listed. */
    fun shouldShow(packageName: String, ownPackage: String, isGroupSummary: Boolean): Boolean =
        packageName != ownPackage && !isGroupSummary
}

/**
 * The live notification list. It only ever contains what the listener service reported; when the listener
 * disconnects the list is cleared (the state is unknown), never kept stale.
 */
@Singleton
class NotificationStore @Inject constructor() {
    private val _items = MutableStateFlow<List<NotificationItem>>(emptyList())
    private val _connected = MutableStateFlow(false)
    val items: StateFlow<List<NotificationItem>> = _items.asStateFlow()
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    @Volatile var actions: NotificationActions? = null
        private set

    private fun sorted(list: List<NotificationItem>) = list.sortedByDescending { it.postTime }

    fun onConnected(initial: List<NotificationItem>, actions: NotificationActions) {
        this.actions = actions
        _items.value = sorted(initial.distinctBy { it.key })
        _connected.value = true
    }

    fun onDisconnected() {
        actions = null
        _items.value = emptyList()
        _connected.value = false
    }

    fun onPosted(item: NotificationItem) {
        _items.update { cur -> sorted(cur.filterNot { it.key == item.key } + item) }
    }

    fun onRemoved(key: String) {
        _items.update { cur -> cur.filterNot { it.key == key } }
    }
}
