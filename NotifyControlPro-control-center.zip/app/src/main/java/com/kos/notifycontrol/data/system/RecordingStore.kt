package com.kos.notifycontrol.data.system

import com.kos.notifycontrol.domain.model.Recording
import java.io.File
import java.io.IOException
import java.nio.file.FileAlreadyExistsException
import java.nio.file.Files

/**
 * File handling for recordings, with no Android dependency (unit-testable).
 * While recording, audio goes to "<name>.m4a.part"; it only becomes "<name>.m4a" after a successful stop,
 * so a failed or interrupted recording never shows up as a real recording and stale parts are purged.
 * Names are unique: two recordings started in the same second get "_2", "_3"... and nothing is ever overwritten.
 */
class RecordingStore(private val dir: File) {
    init { dir.mkdirs() }

    private fun stem(timestamp: String, n: Int) = if (n == 1) "rec_$timestamp" else "rec_${timestamp}_$n"

    /**
     * Atomically reserves a free name by creating the (empty) part file; a name is free only if neither
     * "<stem>.m4a" nor "<stem>.m4a.part" exists. Throws IOException if no name can be reserved.
     */
    fun newPartFile(timestamp: String): File {
        for (n in 1..MAX_ATTEMPTS) {
            val s = stem(timestamp, n)
            if (File(dir, "$s.m4a").exists()) continue
            val part = File(dir, "$s.m4a.part")
            if (part.createNewFile()) return part
        }
        throw IOException("No free recording name for $timestamp")
    }

    /**
     * Moves the part file to its final name without ever replacing an existing recording
     * (on a name clash the next free "_n" name is used). Returns null if that failed.
     */
    fun commit(part: File): File? {
        val base = part.name.removeSuffix(".part").removeSuffix(".m4a")
        for (n in 1..MAX_ATTEMPTS) {
            val target = File(dir, if (n == 1) "$base.m4a" else "${base}_$n.m4a")
            try {
                Files.move(part.toPath(), target.toPath()) // no REPLACE_EXISTING: fails if target exists
                return target
            } catch (e: FileAlreadyExistsException) {
                continue
            } catch (e: IOException) {
                return null
            }
        }
        return null
    }

    fun discard(file: File) { file.delete() }

    /** Deletes leftover part files (e.g. after a crash) except the one currently being written. */
    fun purgeStale(active: File?) {
        dir.listFiles { f -> f.name.endsWith(".part") && f.absolutePath != active?.absolutePath }
            ?.forEach { it.delete() }
    }

    fun list(active: File?): List<Recording> {
        purgeStale(active)
        return dir.listFiles { f -> f.isFile && f.extension == "m4a" }
            ?.sortedWith(compareByDescending<File> { it.lastModified() }.thenByDescending { it.name })
            ?.map { Recording(it.name, it.absolutePath, it.length(), it.lastModified()) }
            ?: emptyList()
    }

    /** Refuses names that point outside the recordings directory. */
    fun delete(name: String): Boolean {
        val f = File(dir, name)
        return f.canonicalFile.parentFile == dir.canonicalFile && f.isFile && f.delete()
    }

    private companion object { const val MAX_ATTEMPTS = 1000 }
}
