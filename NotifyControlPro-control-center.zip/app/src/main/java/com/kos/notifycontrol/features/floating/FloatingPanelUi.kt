package com.kos.notifycontrol.features.floating

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.kos.notifycontrol.R
import com.kos.notifycontrol.domain.model.ControlCenterState
import com.kos.notifycontrol.domain.model.TileId
import com.kos.notifycontrol.domain.model.VolumeStream
import com.kos.notifycontrol.features.controlcenter.ControlCenterContent

/**
 * Collapsed: a small handle just below the status bar; drag it down (or tap it) to open the panel.
 * Expanded: a scrim with the same control center as the app. It never replaces the system notification shade.
 */
@Composable
fun FloatingPanelUi(
    state: ControlCenterState,
    expanded: Boolean,
    topInsetDp: Float,
    onExpand: () -> Unit,
    onCollapse: () -> Unit,
    onTile: (TileId) -> Unit,
    onBrightness: (Int) -> Unit,
    onVolume: (VolumeStream, Int) -> Unit,
    onGrantWriteSettings: () -> Unit,
    onOpenApp: () -> Unit
) {
    if (!expanded) {
        Handle(Color(state.accent.argb), onExpand)
        return
    }
    Box(
        Modifier.fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onCollapse)
    ) {
        Surface(
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = topInsetDp.dp)
                .pointerInput(Unit) { detectTapGestures { } }, // taps inside the panel must not close it
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.background.copy(alpha = state.panelAlpha)
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onOpenApp) { Text(stringResource(R.string.open_app)) }
                    IconButton(onClick = onCollapse) {
                        androidx.compose.material3.Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.close_panel))
                    }
                }
                ControlCenterContent(state, onTile, onBrightness, onVolume, onGrantWriteSettings)
            }
        }
    }
}

@Composable
private fun Handle(accent: Color, onExpand: () -> Unit) {
    val threshold = with(LocalDensity.current) { 24.dp.toPx() }
    val description = stringResource(R.string.floating_handle_description)
    Box(
        Modifier.fillMaxSize()
            .background(accent.copy(alpha = 0.85f), RoundedCornerShape(14.dp))
            .semantics { contentDescription = description }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = { if (total > threshold) onExpand() }
                )
            }
            .clickable(onClick = onExpand),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.width(40.dp).height(4.dp).background(Color.White, RoundedCornerShape(2.dp)))
    }
}
