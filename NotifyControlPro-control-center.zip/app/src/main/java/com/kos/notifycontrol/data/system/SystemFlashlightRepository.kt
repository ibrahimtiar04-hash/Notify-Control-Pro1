package com.kos.notifycontrol.data.system

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.FlashlightState
import com.kos.notifycontrol.domain.model.RequestResult
import com.kos.notifycontrol.domain.repository.FlashlightRepository
import com.kos.notifycontrol.domain.tools.TorchLookup
import com.kos.notifycontrol.domain.tools.TorchResolver
import com.kos.notifycontrol.domain.tools.TorchSource
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

@Singleton
class SystemFlashlightRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : FlashlightRepository {
    private val cm = context.getSystemService(CameraManager::class.java)

    private val source = object : TorchSource {
        override fun hasFlashFeature() = context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
        override fun cameraIds(): List<String> = cm.cameraIdList.toList()
        override fun hasFlash(id: String) =
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        override fun isBackFacing(id: String) =
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
    }

    /** Re-evaluated on every collection and request, so a transient camera-service failure is not cached. */
    private fun lookup(): TorchLookup = TorchResolver.resolve(source)

    /** The ONLY source of the torch state: real values come from CameraManager.TorchCallback. */
    override val state: Flow<FlashlightState> = callbackFlow<FlashlightState> {
        var callback: CameraManager.TorchCallback? = null
        when (val l = lookup()) {
            TorchLookup.None -> trySend(FlashlightState.UNSUPPORTED)
            TorchLookup.Failed -> trySend(FlashlightState.UNKNOWN)
            is TorchLookup.Found -> {
                val cb = object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        if (cameraId == l.id) trySend(if (enabled) FlashlightState.ON else FlashlightState.OFF)
                    }
                    override fun onTorchModeUnavailable(cameraId: String) {
                        if (cameraId == l.id) trySend(FlashlightState.UNAVAILABLE)
                    }
                }
                try {
                    cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
                    callback = cb
                } catch (e: CameraAccessException) {
                    trySend(FlashlightState.UNKNOWN)
                } catch (e: RuntimeException) { // includes SecurityException
                    trySend(FlashlightState.UNKNOWN)
                }
            }
        }
        awaitClose {
            callback?.let {
                try { cm.unregisterTorchCallback(it) } catch (e: RuntimeException) { /* already gone */ }
            }
        }
    }

    /**
     * Accepted means only that CameraManager.setTorchMode() did not throw. It does NOT mean the torch is on/off:
     * the new state is confirmed (or never changes, e.g. camera in use) through [state] / TorchCallback.
     */
    override fun setTorch(on: Boolean): RequestResult {
        val id = when (val l = lookup()) {
            is TorchLookup.Found -> l.id
            TorchLookup.None -> return RequestResult.Rejected(ActionError.UNSUPPORTED)
            TorchLookup.Failed -> return RequestResult.Rejected(ActionError.FAILED)
        }
        return try {
            cm.setTorchMode(id, on)
            RequestResult.Accepted
        } catch (e: CameraAccessException) {
            RequestResult.Rejected(ActionError.FAILED)
        } catch (e: SecurityException) {
            RequestResult.Rejected(ActionError.PERMISSION_REQUIRED)
        } catch (e: RuntimeException) { // IllegalArgumentException and anything else the service throws
            RequestResult.Rejected(ActionError.FAILED)
        }
    }
}
