package com.kos.notifycontrol.features.controlcenter

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.ErrorText
import com.kos.notifycontrol.domain.model.*
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlin.math.roundToInt

@DrawableRes
private fun iconFor(id: TileId) = when (id) {
    TileId.WIFI -> R.drawable.ic_wifi
    TileId.BLUETOOTH -> R.drawable.ic_bluetooth
    TileId.FLASHLIGHT -> R.drawable.ic_flashlight
    TileId.LOCATION -> R.drawable.ic_location
    TileId.AIRPLANE -> R.drawable.ic_airplane
    TileId.DND -> R.drawable.ic_dnd
    TileId.AUTO_ROTATE -> R.drawable.ic_rotate
}

@StringRes
fun tileLabel(id: TileId) = when (id) {
    TileId.WIFI -> R.string.tile_wifi
    TileId.BLUETOOTH -> R.string.tile_bluetooth
    TileId.FLASHLIGHT -> R.string.tile_flashlight
    TileId.LOCATION -> R.string.tile_location
    TileId.AIRPLANE -> R.string.tile_airplane
    TileId.DND -> R.string.tile_dnd
    TileId.AUTO_ROTATE -> R.string.tile_auto_rotate
}

@Composable
private fun statusLabel(s: TileStatus) = stringResource(when (s) {
    TileStatus.ON -> R.string.on
    TileStatus.OFF -> R.string.off
    TileStatus.UNKNOWN -> R.string.dnd_status_unknown
    TileStatus.UNAVAILABLE -> R.string.unavailable
    TileStatus.PERMISSION_REQUIRED -> R.string.permission_required
})

/** Stateless control center: used by the app screen and by the floating panel. */
@Composable
fun ControlCenterContent(
    state: ControlCenterState,
    onTile: (TileId) -> Unit,
    onBrightness: (Int) -> Unit,
    onVolume: (VolumeStream, Int) -> Unit,
    onGrantWriteSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = Color(state.accent.argb)
    val card = MaterialTheme.colorScheme.surface.copy(alpha = state.panelAlpha)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        state.now?.let { t ->
            Column {
                Text(t.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)), style = MaterialTheme.typography.displaySmall)
                Text(t.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)), style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (state.tiles.isEmpty()) Text(stringResource(R.string.no_tiles))
        state.tiles.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { tile -> ControlTile(tile, accent, card, Modifier.weight(1f)) { onTile(tile.id) } }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }

        Surface(shape = RoundedCornerShape(20.dp), color = card, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                BrightnessSection(state, onBrightness, onGrantWriteSettings)
                VolumeSection(state, onVolume)
            }
        }

        BatterySection(state, card)
        ErrorText(state.error)
    }
}

@Composable
private fun ControlTile(tile: TileState, accent: Color, card: Color, modifier: Modifier, onClick: () -> Unit) {
    val active = tile.status == TileStatus.ON
    val dim = tile.status == TileStatus.UNAVAILABLE || tile.status == TileStatus.UNKNOWN
    val container = if (active) accent else card
    val content = if (active) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = if (dim) 0.5f else 1f)
    val name = stringResource(tileLabel(tile.id))
    val status = statusLabel(tile.status)
    Column(
        modifier
            .heightIn(min = 88.dp)
            .background(container, RoundedCornerShape(20.dp))
            .semantics(mergeDescendants = true) { stateDescription = status; contentDescription = name }
            .clickable(role = Role.Button, onClick = onClick)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(painterResource(iconFor(tile.id)), contentDescription = null, tint = content, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(4.dp))
        Text(name, color = content, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 1)
        Text(status, color = content.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun BrightnessSection(state: ControlCenterState, onBrightness: (Int) -> Unit, onGrant: () -> Unit) {
    Text(stringResource(R.string.brightness_title), style = MaterialTheme.typography.labelLarge)
    val raw = state.brightness
    if (raw == null) {
        Text(stringResource(R.string.unavailable))
        return
    }
    var drag by remember(raw) { mutableStateOf<Float?>(null) }
    val shown = drag ?: raw.toFloat()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(stringResource(R.string.brightness_system), style = MaterialTheme.typography.bodySmall)
        Text(stringResource(R.string.percent_fmt, (shown * 100 / 255f).roundToInt()), style = MaterialTheme.typography.bodySmall)
    }
    Slider(
        value = shown.coerceIn(1f, 255f),
        onValueChange = { drag = it },
        onValueChangeFinished = { drag?.let { onBrightness(it.roundToInt()) }; drag = null },
        valueRange = 1f..255f,
        enabled = state.canWriteSettings
    )
    if (!state.canWriteSettings) {
        Text(stringResource(R.string.permission_required), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Text(stringResource(R.string.write_settings_explain), style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = onGrant) { Text(stringResource(R.string.grant_permission)) }
    }
}

@Composable
private fun VolumeSection(state: ControlCenterState, onVolume: (VolumeStream, Int) -> Unit) {
    Text(stringResource(R.string.volume_title), style = MaterialTheme.typography.labelLarge)
    when {
        state.volumeAvailability == VolumeAvailability.FIXED -> Text(stringResource(R.string.action_unsupported))
        state.volumeAvailability == VolumeAvailability.UNKNOWN || state.volumes.isEmpty() ->
            Text(stringResource(R.string.volume_unknown))
        else -> state.volumes.forEach { v -> VolumeRow(v, onVolume) }
    }
}

@Composable
private fun VolumeRow(v: VolumeState, onVolume: (VolumeStream, Int) -> Unit) {
    val label = if (v.stream == VolumeStream.MEDIA) R.string.vol_media else R.string.vol_ring
    var drag by remember(v.current) { mutableStateOf<Float?>(null) }
    val shown = drag ?: v.current.toFloat()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(stringResource(label), style = MaterialTheme.typography.bodySmall)
        Text("${shown.roundToInt()} / ${v.max}", style = MaterialTheme.typography.bodySmall)
    }
    if (v.canAdjust) {
        Slider(
            value = shown.coerceIn(v.min.toFloat(), v.max.toFloat()),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { onVolume(v.stream, it.roundToInt()) }; drag = null },
            valueRange = v.min.toFloat()..v.max.toFloat(),
            steps = (v.max - v.min - 1).coerceAtLeast(0)
        )
    }
}

@Composable
private fun BatterySection(state: ControlCenterState, card: Color) {
    val b = state.battery ?: return
    Surface(shape = RoundedCornerShape(20.dp), color = card, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.battery_title), style = MaterialTheme.typography.labelLarge)
                Text(b.levelPercent?.let { stringResource(R.string.percent_fmt, it) } ?: stringResource(R.string.unavailable))
            }
            b.levelPercent?.let { LinearProgressIndicator(progress = { it / 100f }, modifier = Modifier.fillMaxWidth()) }
            val charging = when (b.charging) {
                ChargingStatus.CHARGING -> R.string.status_charging
                ChargingStatus.DISCHARGING -> R.string.status_discharging
                ChargingStatus.FULL -> R.string.status_full
                ChargingStatus.NOT_CHARGING -> R.string.status_not_charging
                ChargingStatus.UNKNOWN -> null
            }
            Text(charging?.let { stringResource(it) } ?: stringResource(R.string.unavailable), style = MaterialTheme.typography.bodySmall)
        }
    }
}
