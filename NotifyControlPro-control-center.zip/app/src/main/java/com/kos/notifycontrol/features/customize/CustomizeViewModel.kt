package com.kos.notifycontrol.features.customize

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.AccentColor
import com.kos.notifycontrol.domain.model.Customization
import com.kos.notifycontrol.domain.model.TileId
import com.kos.notifycontrol.domain.model.TileLayout
import com.kos.notifycontrol.domain.repository.CustomizationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class CustomizeViewModel @Inject constructor(private val repo: CustomizationRepository) : ViewModel() {
    /** What is persisted; defaults only until DataStore reports. */
    val state: StateFlow<Customization> =
        repo.customization.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), Customization.default())

    fun moveUp(id: TileId) = launch { repo.setSlots(TileLayout.moveUp(state.value.slots, id)) }
    fun moveDown(id: TileId) = launch { repo.setSlots(TileLayout.moveDown(state.value.slots, id)) }
    fun setEnabled(id: TileId, on: Boolean) = launch { repo.setSlots(TileLayout.setEnabled(state.value.slots, id, on)) }
    fun setAccent(a: AccentColor) = launch { repo.setAccent(a) }
    fun setPanelAlpha(v: Float) = launch { repo.setPanelAlpha(v) }
    fun reset() = launch { repo.reset() }

    private fun launch(block: suspend () -> Unit) { viewModelScope.launch { block() } }
}
