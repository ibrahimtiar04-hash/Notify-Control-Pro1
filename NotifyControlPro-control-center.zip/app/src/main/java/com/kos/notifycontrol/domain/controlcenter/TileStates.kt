package com.kos.notifycontrol.domain.controlcenter

import com.kos.notifycontrol.domain.model.*

/** Pure mapping from real system snapshots to tile states. No defaults: anything unreadable is UNKNOWN/UNAVAILABLE. */
object TileStates {
    fun of(
        id: TileId,
        network: NetworkSnapshot,
        sound: SoundSnapshot,
        display: DisplaySnapshot,
        flashlight: FlashlightState?,
        locationEnabled: Boolean?
    ): TileState = TileState(id, when (id) {
        TileId.WIFI -> toggle(network.wifi)
        TileId.BLUETOOTH -> toggle(network.bluetooth)
        TileId.FLASHLIGHT -> when (flashlight) {
            FlashlightState.ON -> TileStatus.ON
            FlashlightState.OFF -> TileStatus.OFF
            FlashlightState.UNSUPPORTED, FlashlightState.UNAVAILABLE -> TileStatus.UNAVAILABLE
            FlashlightState.UNKNOWN, null -> TileStatus.UNKNOWN
        }
        TileId.LOCATION -> bool(locationEnabled)
        TileId.AIRPLANE -> bool(network.airplaneMode)
        TileId.DND -> when (DndUi.from(sound.dnd).status) {
            DndStatus.ON -> TileStatus.ON
            DndStatus.OFF -> TileStatus.OFF
            DndStatus.UNKNOWN -> TileStatus.UNKNOWN
        }
        TileId.AUTO_ROTATE -> bool(display.autoRotate)
    })

    fun visibleTiles(
        slots: List<TileSlot>, network: NetworkSnapshot, sound: SoundSnapshot, display: DisplaySnapshot,
        flashlight: FlashlightState?, locationEnabled: Boolean?
    ): List<TileState> = TileLayout.visible(slots).map { of(it, network, sound, display, flashlight, locationEnabled) }

    private fun bool(v: Boolean?) = when (v) { true -> TileStatus.ON; false -> TileStatus.OFF; null -> TileStatus.UNKNOWN }

    private fun toggle(t: ToggleState?): TileStatus = when (t) {
        null -> TileStatus.UNAVAILABLE
        ToggleState.ON, ToggleState.TURNING_ON -> TileStatus.ON
        ToggleState.OFF, ToggleState.TURNING_OFF -> TileStatus.OFF
        ToggleState.UNKNOWN -> TileStatus.UNKNOWN
        ToggleState.PERMISSION_REQUIRED -> TileStatus.PERMISSION_REQUIRED
    }
}
