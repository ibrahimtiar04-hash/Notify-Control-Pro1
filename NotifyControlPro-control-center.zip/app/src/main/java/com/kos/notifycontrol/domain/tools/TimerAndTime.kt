package com.kos.notifycontrol.domain.tools

import java.util.Locale

fun interface TimeSource { fun elapsedMillis(): Long }

enum class TimerStatus { IDLE, RUNNING, FINISHED }

object TimerLogic {
    const val MAX_MILLIS = 24L * 60 * 60 * 1000

    fun status(endAt: Long?, now: Long): TimerStatus = when {
        endAt == null -> TimerStatus.IDLE
        endAt > now -> TimerStatus.RUNNING
        else -> TimerStatus.FINISHED
    }

    fun remainingMillis(endAt: Long, now: Long): Long = (endAt - now).coerceAtLeast(0)

    /** Notifications can be shown only if the app's notifications are enabled and, on Android 13+, the permission is granted. */
    fun notificationsAllowed(sdkInt: Int, appNotificationsEnabled: Boolean, permissionGranted: Boolean): Boolean =
        appNotificationsEnabled && (sdkInt < 33 || permissionGranted)

    /** Blank counts as 0; digits only; total must be 1 second .. 24 hours. Otherwise null. */
    fun parseDuration(minutes: String, seconds: String): Long? {
        fun part(t: String): Long? = when {
            t.isBlank() -> 0L
            t.length <= 6 && t.all { it.isDigit() } -> t.toLong()
            else -> null
        }
        val m = part(minutes) ?: return null
        val s = part(seconds) ?: return null
        val ms = (m * 60 + s) * 1000
        return ms.takeIf { it in 1000..MAX_MILLIS }
    }
}

/** mm:ss (or h:mm:ss from one hour) and, optionally, hundredths. Seconds are rounded up for countdowns. */
fun formatClock(millis: Long, withCentis: Boolean, locale: Locale = Locale.getDefault()): String {
    val total = millis.coerceAtLeast(0)
    val seconds = if (withCentis) total / 1000 else (total + 999) / 1000
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    val base = if (h > 0) String.format(locale, "%d:%02d:%02d", h, m, s) else String.format(locale, "%02d:%02d", m, s)
    return if (withCentis) base + String.format(locale, ".%02d", (total % 1000) / 10) else base
}

class Stopwatch(private val time: TimeSource) {
    private var accumulated = 0L
    private var startedAt: Long? = null
    private val _laps = mutableListOf<Long>()
    val laps: List<Long> get() = _laps.toList()
    val isRunning: Boolean get() = startedAt != null

    fun elapsedMillis(): Long = accumulated + (startedAt?.let { time.elapsedMillis() - it } ?: 0L)
    fun start() { if (startedAt == null) startedAt = time.elapsedMillis() }
    fun pause() { startedAt?.let { accumulated += time.elapsedMillis() - it; startedAt = null } }
    fun reset() { accumulated = 0; startedAt = null; _laps.clear() }
    fun lap(): Boolean { if (!isRunning) return false; _laps.add(elapsedMillis()); return true }
}
