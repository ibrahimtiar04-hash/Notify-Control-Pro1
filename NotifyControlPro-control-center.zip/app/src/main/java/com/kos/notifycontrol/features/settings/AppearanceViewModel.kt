package com.kos.notifycontrol.features.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.AccentColor
import com.kos.notifycontrol.domain.model.ThemeMode
import com.kos.notifycontrol.domain.repository.CustomizationRepository
import com.kos.notifycontrol.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** App-wide look: theme mode (system/light/dark) and the user's accent color. */
@HiltViewModel
class AppearanceViewModel @Inject constructor(
    settings: SettingsRepository,
    customization: CustomizationRepository
) : ViewModel() {
    val themeMode: StateFlow<ThemeMode> = settings.themeMode.stateIn(viewModelScope, SharingStarted.Eagerly, ThemeMode.SYSTEM)
    val accent: StateFlow<AccentColor> =
        customization.customization.map { it.accent }.stateIn(viewModelScope, SharingStarted.Eagerly, AccentColor.BLUE)
}
