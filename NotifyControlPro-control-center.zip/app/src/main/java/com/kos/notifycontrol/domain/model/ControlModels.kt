package com.kos.notifycontrol.domain.model

enum class ActionError { PERMISSION_REQUIRED, UNSUPPORTED, FAILED }

/** Success carries the value read back from the system after the change, never an assumed value. */
sealed interface ActionResult {
    data class Success(val verifiedValue: Int) : ActionResult
    data class Failure(val error: ActionError) : ActionResult
}

enum class VolumeStream { MEDIA, RING, ALARM, NOTIFICATION, CALL }

/** FIXED = the device really has fixed volume; UNKNOWN = the system refused to say (never treated as FIXED). */
enum class VolumeAvailability {
    AVAILABLE, FIXED, UNKNOWN;
    companion object {
        fun from(isVolumeFixed: Boolean?): VolumeAvailability = when (isVolumeFixed) {
            true -> FIXED
            false -> AVAILABLE
            null -> UNKNOWN
        }
    }
}

data class VolumeState(val stream: VolumeStream, val current: Int, val min: Int, val max: Int) {
    val canAdjust: Boolean get() = max > min
    val fraction: Float get() = if (max > min) ((current - min).toFloat() / (max - min)).coerceIn(0f, 1f) else 0f
}

enum class RingerMode { NORMAL, VIBRATE, SILENT }

enum class DndFilter { ALL, PRIORITY, ALARMS_ONLY, NONE, UNKNOWN }

/** UNKNOWN = the system refused to say (SecurityException); it is never folded into NOT_GRANTED. */
enum class PolicyAccess { GRANTED, NOT_GRANTED, UNKNOWN }

data class DndState(val access: PolicyAccess, val filter: DndFilter) {
    val isOn: Boolean get() = filter == DndFilter.PRIORITY || filter == DndFilter.ALARMS_ONLY || filter == DndFilter.NONE
    val canToggle: Boolean get() = access == PolicyAccess.GRANTED
}

data class SoundSnapshot(
    /** Empty unless [volumeAvailability] is AVAILABLE (and a stream may still be missing if its read was refused). */
    val volumes: List<VolumeState>,
    val ringer: RingerMode?,
    val dnd: DndState,
    val volumeAvailability: VolumeAvailability
)

/** null fields = the system did not provide the value. */
data class DisplaySnapshot(
    val brightness: Int?,          // raw system value 0..255
    val autoBrightness: Boolean?,
    val canWriteSettings: Boolean,
    val screenTimeoutMs: Int?,
    val autoRotate: Boolean?,
    val fontScale: Float,
    val darkTheme: Boolean
)

/**
 * Result of a request the system only ACCEPTS: the real outcome is confirmed later by a system callback or
 * broadcast (torch callback, interruption-filter change), never by this value.
 */
sealed interface RequestResult {
    data object Accepted : RequestResult
    data class Rejected(val error: ActionError) : RequestResult
}
