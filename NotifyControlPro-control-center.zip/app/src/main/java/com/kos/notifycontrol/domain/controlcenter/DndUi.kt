package com.kos.notifycontrol.domain.controlcenter

import com.kos.notifycontrol.domain.model.DndFilter
import com.kos.notifycontrol.domain.model.DndState
import com.kos.notifycontrol.domain.model.PolicyAccess

enum class DndStatus { ON, OFF, UNKNOWN }

/** What the DND row shows. UNKNOWN is never shown as OFF, and the toggle is disabled while unknown. */
data class DndUi(val status: DndStatus, val toggleEnabled: Boolean) {
    companion object {
        fun from(dnd: DndState): DndUi {
            val status = when (dnd.filter) {
                DndFilter.UNKNOWN -> DndStatus.UNKNOWN
                DndFilter.ALL -> DndStatus.OFF
                DndFilter.PRIORITY, DndFilter.ALARMS_ONLY, DndFilter.NONE -> DndStatus.ON
            }
            return DndUi(status, toggleEnabled = status != DndStatus.UNKNOWN && dnd.access == PolicyAccess.GRANTED)
        }
    }
}
