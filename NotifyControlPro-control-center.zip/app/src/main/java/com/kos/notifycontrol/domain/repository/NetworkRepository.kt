package com.kos.notifycontrol.domain.repository

import com.kos.notifycontrol.domain.model.NetworkSnapshot
import kotlinx.coroutines.flow.Flow

interface NetworkRepository {
    fun read(): NetworkSnapshot
    /** Emits on Wi-Fi / Bluetooth / airplane-mode broadcasts and default-network changes. */
    val changes: Flow<Unit>
}
