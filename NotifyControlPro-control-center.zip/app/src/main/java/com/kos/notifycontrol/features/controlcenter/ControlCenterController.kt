package com.kos.notifycontrol.features.controlcenter

import com.kos.notifycontrol.domain.controlcenter.DndStatus
import com.kos.notifycontrol.domain.controlcenter.DndUi
import com.kos.notifycontrol.domain.controlcenter.TileStates
import com.kos.notifycontrol.domain.model.*
import com.kos.notifycontrol.domain.repository.*
import java.time.ZonedDateTime
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch

class ControlCenterControllerFactory @Inject constructor(
    private val network: NetworkRepository,
    private val sound: SoundRepository,
    private val display: DisplayRepository,
    private val flashlight: FlashlightRepository,
    private val battery: BatteryRepository,
    private val clock: ClockRepository,
    private val location: LocationRepository,
    private val customization: CustomizationRepository
) {
    /** [supportsDialogs] = the host can show system dialogs (app screen yes, overlay window no). */
    fun create(scope: CoroutineScope, supportsDialogs: Boolean) = ControlCenterController(
        scope, network, sound, display, flashlight, battery, clock, location, customization, supportsDialogs
    )
}

/**
 * Holds the control-center state. Every value comes from a real system read or callback; tile clicks either
 * change the setting where Android allows it, or return a [TileEffect] telling the host which system screen to open.
 * Observation runs only between [start] and [stop] (the host starts it while the UI is visible).
 */
class ControlCenterController(
    private val scope: CoroutineScope,
    private val network: NetworkRepository,
    private val sound: SoundRepository,
    private val display: DisplayRepository,
    private val flashlight: FlashlightRepository,
    private val battery: BatteryRepository,
    private val clock: ClockRepository,
    private val location: LocationRepository,
    private val customization: CustomizationRepository,
    private val supportsDialogs: Boolean
) {
    private var flash: FlashlightState? = null
    private var batteryState: BatteryState? = null
    private var now: ZonedDateTime? = null
    private var custom: Customization = Customization.default()
    private var error: ActionError? = null
    private var jobs: List<Job> = emptyList()

    private val _state = MutableStateFlow(build())
    val state: StateFlow<ControlCenterState> = _state.asStateFlow()

    private fun build(): ControlCenterState {
        val net = network.read()
        val snd = sound.read()
        val dsp = display.read()
        val loc = location.read()
        return ControlCenterState(
            tiles = TileStates.visibleTiles(custom.slots, net, snd, dsp, flash, loc),
            brightness = dsp.brightness,
            autoBrightness = dsp.autoBrightness,
            canWriteSettings = dsp.canWriteSettings,
            volumes = snd.volumes.filter { it.stream == VolumeStream.MEDIA || it.stream == VolumeStream.RING },
            volumeAvailability = snd.volumeAvailability,
            battery = batteryState,
            now = now,
            accent = custom.accent,
            panelAlpha = custom.panelAlpha,
            error = error
        )
    }

    private fun rebuild() { _state.value = build() }

    fun start() {
        if (jobs.isNotEmpty()) return
        jobs = listOf(
            scope.launch { merge(network.changes, sound.changes, display.changes, location.changes).collect { rebuild() } },
            scope.launch { flashlight.state.collect { flash = it; rebuild() } },
            scope.launch { battery.state.collect { batteryState = it; rebuild() } },
            scope.launch { clock.now.collect { now = it; rebuild() } },
            scope.launch { customization.customization.collect { custom = it; rebuild() } }
        )
        rebuild()
    }

    fun stop() {
        jobs.forEach { it.cancel() }
        jobs = emptyList()
    }

    /** Re-reads everything (volume has no public change broadcast, so hosts call this on resume / expand). */
    fun refresh() = rebuild()

    fun clearError() { error = null; rebuild() }

    private fun reject(e: ActionError): TileEffect { error = e; return TileEffect.Rejected(e) }

    fun onTileClick(id: TileId): TileEffect {
        error = null
        val effect: TileEffect = when (id) {
            TileId.WIFI -> TileEffect.Launch(SystemScreen.WIFI_PANEL)          // Android blocks direct Wi-Fi toggling
            TileId.LOCATION -> TileEffect.Launch(SystemScreen.LOCATION_SETTINGS)
            TileId.AIRPLANE -> TileEffect.Launch(SystemScreen.AIRPLANE_SETTINGS)
            TileId.BLUETOOTH -> bluetoothClick()
            TileId.FLASHLIGHT -> flashlightClick()
            TileId.DND -> dndClick()
            TileId.AUTO_ROTATE -> autoRotateClick()
        }
        rebuild()
        return effect
    }

    private fun bluetoothClick(): TileEffect {
        val bt = network.read().bluetooth
        return when {
            bt == null -> reject(ActionError.UNSUPPORTED)
            !supportsDialogs -> TileEffect.Launch(SystemScreen.BLUETOOTH_SETTINGS)
            bt == ToggleState.PERMISSION_REQUIRED -> TileEffect.RequestBluetoothPermission
            bt == ToggleState.OFF -> TileEffect.RequestBluetoothEnable
            else -> TileEffect.Launch(SystemScreen.BLUETOOTH_SETTINGS)
        }
    }

    private fun flashlightClick(): TileEffect = when (flash) {
        FlashlightState.ON -> torch(false)
        FlashlightState.OFF -> torch(true)
        FlashlightState.UNSUPPORTED, FlashlightState.UNAVAILABLE -> reject(ActionError.UNSUPPORTED)
        FlashlightState.UNKNOWN, null -> reject(ActionError.FAILED)
    }

    /** Accepted only means the request was accepted: the tile state changes when TorchCallback reports it. */
    private fun torch(on: Boolean): TileEffect =
        (flashlight.setTorch(on) as? RequestResult.Rejected)?.let { reject(it.error) } ?: TileEffect.None

    private fun dndClick(): TileEffect {
        val dnd = sound.read().dnd
        val ui = DndUi.from(dnd)
        return when {
            ui.toggleEnabled ->
                (sound.setDnd(ui.status != DndStatus.ON) as? RequestResult.Rejected)?.let { reject(it.error) } ?: TileEffect.None
            dnd.access != PolicyAccess.GRANTED -> TileEffect.Launch(SystemScreen.DND_ACCESS)
            else -> reject(ActionError.FAILED) // access granted but the current state is unknown
        }
    }

    private fun autoRotateClick(): TileEffect {
        val d = display.read()
        val current = d.autoRotate
        return when {
            !d.canWriteSettings -> TileEffect.Launch(SystemScreen.WRITE_SETTINGS)
            current == null -> reject(ActionError.FAILED)
            else -> (display.setAutoRotate(!current) as? ActionResult.Failure)?.let { reject(it.error) } ?: TileEffect.None
        }
    }

    fun setBrightness(raw: Int) {
        error = null
        if (!display.read().canWriteSettings) error = ActionError.PERMISSION_REQUIRED
        else (display.setBrightness(raw) as? ActionResult.Failure)?.let { error = it.error }
        rebuild()
    }

    fun setVolume(stream: VolumeStream, level: Int) {
        error = null
        (sound.setVolume(stream, level) as? ActionResult.Failure)?.let { error = it.error }
        rebuild()
    }

    /** After the BLUETOOTH_CONNECT dialog: always re-read the real state. */
    fun onBluetoothPermissionResult(granted: Boolean) {
        error = if (granted) null else ActionError.PERMISSION_REQUIRED
        rebuild()
    }
}
