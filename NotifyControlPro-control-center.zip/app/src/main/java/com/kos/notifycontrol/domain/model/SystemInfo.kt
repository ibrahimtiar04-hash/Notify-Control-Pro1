package com.kos.notifycontrol.domain.model

enum class ChargingStatus { CHARGING, DISCHARGING, FULL, NOT_CHARGING, UNKNOWN }

/** levelPercent / temperatureCelsius are null when the system did not report them. */
data class BatteryState(
    val levelPercent: Int?,
    val charging: ChargingStatus,
    val temperatureCelsius: Float?
)
