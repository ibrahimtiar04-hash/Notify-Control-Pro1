package com.kos.notifycontrol.domain.tools

/** Minimal view of the camera service needed to pick a torch; implemented over CameraManager. */
interface TorchSource {
    fun hasFlashFeature(): Boolean
    fun cameraIds(): List<String>
    fun hasFlash(id: String): Boolean
    fun isBackFacing(id: String): Boolean
}

sealed interface TorchLookup {
    data class Found(val id: String) : TorchLookup
    /** The device has no flash unit. */
    data object None : TorchLookup
    /** The camera service failed or refused. This is NOT the same as "no flash". */
    data object Failed : TorchLookup
}

object TorchResolver {
    /**
     * Any exception from the camera service (CameraAccessException, SecurityException,
     * IllegalArgumentException, IllegalStateException, RuntimeException...) becomes Failed.
     */
    fun resolve(source: TorchSource): TorchLookup = try {
        if (!source.hasFlashFeature()) {
            TorchLookup.None
        } else {
            val withFlash = source.cameraIds().filter { source.hasFlash(it) }
            val id = withFlash.firstOrNull { source.isBackFacing(it) } ?: withFlash.firstOrNull()
            if (id != null) TorchLookup.Found(id) else TorchLookup.None
        }
    } catch (e: Exception) {
        TorchLookup.Failed
    }
}
