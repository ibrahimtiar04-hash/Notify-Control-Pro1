package com.kos.notifycontrol.domain.model

enum class AccentColor(val argb: Long) {
    BLUE(0xFF3478F6), CYAN(0xFF35C6D8), GREEN(0xFF34C759),
    ORANGE(0xFFFF9500), PINK(0xFFFF2D55), PURPLE(0xFFAF52DE);

    companion object {
        fun fromName(name: String?): AccentColor = entries.firstOrNull { it.name == name } ?: BLUE
    }
}

data class TileSlot(val id: TileId, val enabled: Boolean)

data class Customization(val accent: AccentColor, val panelAlpha: Float, val slots: List<TileSlot>) {
    companion object {
        const val MIN_ALPHA = 0.5f
        fun clampAlpha(v: Float): Float = if (v.isNaN()) 1f else v.coerceIn(MIN_ALPHA, 1f)
        fun default() = Customization(AccentColor.BLUE, 1f, TileLayout.default())
    }
}

/** Order + visibility of the quick tiles. Persisted as "WIFI:1,BLUETOOTH:0,..." and parsed defensively. */
object TileLayout {
    fun default(): List<TileSlot> = TileId.entries.map { TileSlot(it, true) }

    fun serialize(slots: List<TileSlot>): String =
        slots.joinToString(",") { "${it.id.name}:${if (it.enabled) 1 else 0}" }

    /** Unknown ids and duplicates are dropped; tiles missing from the stored value are appended (enabled). */
    fun parse(raw: String?): List<TileSlot> {
        val found = LinkedHashMap<TileId, Boolean>()
        raw?.split(",")?.forEach { part ->
            val pieces = part.split(":")
            val id = TileId.entries.firstOrNull { it.name == pieces.getOrNull(0) } ?: return@forEach
            if (id !in found) found[id] = pieces.getOrNull(1) != "0"
        }
        TileId.entries.forEach { if (it !in found) found[it] = true }
        return found.map { TileSlot(it.key, it.value) }
    }

    fun visible(slots: List<TileSlot>): List<TileId> = slots.filter { it.enabled }.map { it.id }

    fun moveUp(slots: List<TileSlot>, id: TileId): List<TileSlot> {
        val i = slots.indexOfFirst { it.id == id }
        if (i <= 0) return slots
        return slots.toMutableList().also { val t = it[i]; it[i] = it[i - 1]; it[i - 1] = t }
    }

    fun moveDown(slots: List<TileSlot>, id: TileId): List<TileSlot> {
        val i = slots.indexOfFirst { it.id == id }
        if (i < 0 || i >= slots.lastIndex) return slots
        return slots.toMutableList().also { val t = it[i]; it[i] = it[i + 1]; it[i + 1] = t }
    }

    /** The last visible tile cannot be hidden (an empty control center would be useless). */
    fun setEnabled(slots: List<TileSlot>, id: TileId, enabled: Boolean): List<TileSlot> {
        if (!enabled && visible(slots) == listOf(id)) return slots
        return slots.map { if (it.id == id) it.copy(enabled = enabled) else it }
    }
}
