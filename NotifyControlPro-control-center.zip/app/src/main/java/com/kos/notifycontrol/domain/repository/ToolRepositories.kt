package com.kos.notifycontrol.domain.repository

import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.FlashlightState
import com.kos.notifycontrol.domain.model.Recording
import kotlinx.coroutines.flow.Flow

interface FlashlightRepository {
    /** Real torch state from CameraManager.TorchCallback. */
    val state: Flow<FlashlightState>
    /**
     * Asks the system to switch the torch. [RequestResult.Accepted] only means the request was accepted: the
     * torch may stay as it is (e.g. the camera is in use). The real state is ONLY what [state] reports
     * through CameraManager.TorchCallback.
     */
    fun setTorch(on: Boolean): RequestResult
}

interface TimerRepository {
    /** Wall-clock end time of the running timer, persisted; null = no timer. */
    val endAtMillis: Flow<Long?>
    suspend fun start(durationMs: Long): ActionResult
    suspend fun cancel()
    /** Re-arms the notification alarm for a saved, still-future end time (alarms do not survive a reboot). */
    /** Called once, at app start (NotifyControlApp). It is the only restore point: UI code must not call it. */
    suspend fun restore()
}

interface RecorderRepository {
    fun start(): ActionResult
    fun stop(): ActionResult
    fun list(): List<Recording>
    fun delete(name: String): Boolean
}
