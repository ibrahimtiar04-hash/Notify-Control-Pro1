package com.kos.notifycontrol.features.controlcenter

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.ErrorText
import com.kos.notifycontrol.core.designsystem.SettingsIntents
import com.kos.notifycontrol.core.designsystem.launchSettings
import com.kos.notifycontrol.domain.model.*

@Composable
fun ControlCenterScreen(modifier: Modifier = Modifier, vm: ControlCenterViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var launchFailed by remember { mutableStateOf(false) }
    var enableAfterGrant by remember { mutableStateOf(false) }

    // Observation runs only while the screen is visible.
    LaunchedEffect(Unit) { vm.controller.start() }
    DisposableEffect(Unit) { onDispose { vm.controller.stop() } }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { vm.controller.start() }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.controller.stop() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.controller.refresh() }

    val enableLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.controller.refresh() }
    fun launchEnable() {
        runCatching { enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }.onFailure { launchFailed = true }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.controller.onBluetoothPermissionResult(granted) // re-reads the real state
        val btOff = vm.state.value.tiles.firstOrNull { it.id == TileId.BLUETOOTH }?.status == TileStatus.OFF
        if (granted && enableAfterGrant && btOff) launchEnable()
        enableAfterGrant = false
    }
    fun hasBluetoothPermission() = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun handle(effect: TileEffect) {
        when (effect) {
            TileEffect.None, is TileEffect.Rejected -> Unit // a rejection is already shown in the state
            is TileEffect.Launch -> launchFailed = !context.launchSettings(SettingsIntents.of(effect.screen, context.packageName))
            TileEffect.RequestBluetoothEnable ->
                if (hasBluetoothPermission()) launchEnable() else { enableAfterGrant = true; permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
            TileEffect.RequestBluetoothPermission -> { enableAfterGrant = false; permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
        }
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(R.string.control_center_title), style = androidx.compose.material3.MaterialTheme.typography.headlineMedium)
        ControlCenterContent(
            state = state,
            onTile = { handle(vm.controller.onTileClick(it)) },
            onBrightness = vm.controller::setBrightness,
            onVolume = vm.controller::setVolume,
            onGrantWriteSettings = { handle(TileEffect.Launch(SystemScreen.WRITE_SETTINGS)) }
        )
        if (launchFailed) ErrorText(ActionError.UNSUPPORTED)
    }
}
