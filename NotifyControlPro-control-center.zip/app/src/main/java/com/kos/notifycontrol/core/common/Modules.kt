package com.kos.notifycontrol.core.common

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.kos.notifycontrol.data.preferences.DataStoreSettingsRepository
import com.kos.notifycontrol.data.repository.SystemClockRepository
import com.kos.notifycontrol.data.system.DataStoreTimerRepository
import com.kos.notifycontrol.data.preferences.DataStoreCustomizationRepository
import com.kos.notifycontrol.data.system.SystemBatteryRepository
import com.kos.notifycontrol.data.system.SystemLocationRepository
import com.kos.notifycontrol.data.system.SystemNotificationAccess
import com.kos.notifycontrol.domain.repository.CustomizationRepository
import com.kos.notifycontrol.domain.repository.LocationRepository
import com.kos.notifycontrol.domain.repository.NotificationAccess
import com.kos.notifycontrol.data.system.SystemFlashlightRepository
import com.kos.notifycontrol.data.system.SystemRecorderRepository
import com.kos.notifycontrol.data.system.SystemTimeSource
import com.kos.notifycontrol.domain.repository.FlashlightRepository
import com.kos.notifycontrol.domain.repository.RecorderRepository
import com.kos.notifycontrol.domain.repository.TimerRepository
import com.kos.notifycontrol.domain.tools.TimeSource
import com.kos.notifycontrol.data.system.SystemNetworkRepository
import com.kos.notifycontrol.domain.repository.NetworkRepository
import com.kos.notifycontrol.data.system.SystemDisplayRepository
import com.kos.notifycontrol.data.system.SystemSoundRepository
import com.kos.notifycontrol.domain.repository.DisplayRepository
import com.kos.notifycontrol.domain.repository.SoundRepository
import com.kos.notifycontrol.domain.repository.BatteryRepository
import com.kos.notifycontrol.domain.repository.ClockRepository
import com.kos.notifycontrol.domain.repository.SettingsRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

private val Context.settingsDataStore by preferencesDataStore(name = "settings")

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds abstract fun settings(impl: DataStoreSettingsRepository): SettingsRepository
    @Binds abstract fun clock(impl: SystemClockRepository): ClockRepository
    @Binds abstract fun battery(impl: SystemBatteryRepository): BatteryRepository
    @Binds abstract fun display(impl: SystemDisplayRepository): DisplayRepository
    @Binds abstract fun sound(impl: SystemSoundRepository): SoundRepository
    @Binds abstract fun network(impl: SystemNetworkRepository): NetworkRepository
    @Binds abstract fun flashlight(impl: SystemFlashlightRepository): FlashlightRepository
    @Binds abstract fun timer(impl: DataStoreTimerRepository): TimerRepository
    @Binds abstract fun recorder(impl: SystemRecorderRepository): RecorderRepository
    @Binds abstract fun timeSource(impl: SystemTimeSource): TimeSource
    @Binds abstract fun location(impl: SystemLocationRepository): LocationRepository
    @Binds abstract fun customization(impl: DataStoreCustomizationRepository): CustomizationRepository
    @Binds abstract fun notificationAccess(impl: SystemNotificationAccess): NotificationAccess
}

@Module
@InstallIn(SingletonComponent::class)
object DataStoreModule {
    @Provides @Singleton
    fun settingsDataStore(@ApplicationContext context: Context): DataStore<Preferences> =
        context.settingsDataStore
}
