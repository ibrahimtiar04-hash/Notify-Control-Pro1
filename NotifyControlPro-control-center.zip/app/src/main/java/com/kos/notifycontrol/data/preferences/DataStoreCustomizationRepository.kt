package com.kos.notifycontrol.data.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.kos.notifycontrol.domain.model.AccentColor
import com.kos.notifycontrol.domain.model.Customization
import com.kos.notifycontrol.domain.model.TileLayout
import com.kos.notifycontrol.domain.model.TileSlot
import com.kos.notifycontrol.domain.repository.CustomizationRepository
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

@Singleton
class DataStoreCustomizationRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : CustomizationRepository {
    private val accentKey = stringPreferencesKey("accent")
    private val alphaKey = floatPreferencesKey("panel_alpha")
    private val slotsKey = stringPreferencesKey("tile_slots")

    override val customization: Flow<Customization> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            Customization(
                accent = AccentColor.fromName(p[accentKey]),
                panelAlpha = Customization.clampAlpha(p[alphaKey] ?: 1f),
                slots = TileLayout.parse(p[slotsKey])
            )
        }

    // A failed write simply leaves the stored value unchanged; the UI shows what the flow reports.
    private suspend fun write(block: (MutablePreferences) -> Unit) {
        try { dataStore.edit { block(it) } } catch (e: IOException) { /* keep the previous value */ }
    }

    override suspend fun setAccent(accent: AccentColor) = write { it[accentKey] = accent.name }
    override suspend fun setPanelAlpha(alpha: Float) = write { it[alphaKey] = Customization.clampAlpha(alpha) }
    override suspend fun setSlots(slots: List<TileSlot>) = write { it[slotsKey] = TileLayout.serialize(slots) }
    override suspend fun reset() = write { it.remove(accentKey); it.remove(alphaKey); it.remove(slotsKey) }
}
