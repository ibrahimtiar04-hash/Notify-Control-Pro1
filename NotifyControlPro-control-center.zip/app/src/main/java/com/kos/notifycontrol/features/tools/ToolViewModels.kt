package com.kos.notifycontrol.features.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.FlashlightState
import com.kos.notifycontrol.domain.model.Recording
import com.kos.notifycontrol.domain.model.RequestResult
import com.kos.notifycontrol.domain.repository.FlashlightRepository
import com.kos.notifycontrol.domain.repository.RecorderRepository
import com.kos.notifycontrol.domain.repository.TimerRepository
import com.kos.notifycontrol.domain.tools.CalcError
import com.kos.notifycontrol.domain.tools.CalcResult
import com.kos.notifycontrol.domain.tools.CalculatorEngine
import com.kos.notifycontrol.domain.tools.Stopwatch
import com.kos.notifycontrol.domain.tools.TimeSource
import com.kos.notifycontrol.domain.tools.TimerLogic
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// ---------- Calculator ----------
data class CalculatorUi(val expression: String = "", val result: String? = null, val error: CalcError? = null)

@HiltViewModel
class CalculatorViewModel @Inject constructor() : ViewModel() {
    private val _state = MutableStateFlow(CalculatorUi())
    val state: StateFlow<CalculatorUi> = _state.asStateFlow()

    fun onKey(key: Char) {
        val ui = _state.value
        val isOperator = key in "+-×÷%"
        // After "=": an operator continues from the result, anything else starts a new expression.
        val base = if (ui.result != null) (if (isOperator) ui.result else "") else ui.expression
        val next = base + key
        if (next.length <= MAX_LENGTH) _state.value = CalculatorUi(expression = next)
    }

    fun equals() {
        val ui = _state.value
        if (ui.expression.isEmpty() || ui.result != null) return
        _state.value = when (val r = CalculatorEngine.evaluate(ui.expression)) {
            is CalcResult.Value -> ui.copy(result = r.text, error = null)
            is CalcResult.Error -> ui.copy(result = null, error = r.reason)
        }
    }

    fun backspace() {
        val ui = _state.value
        _state.value = CalculatorUi(expression = ui.expression.dropLast(1))
    }

    fun clear() { _state.value = CalculatorUi() }

    private companion object { const val MAX_LENGTH = 60 }
}

// ---------- Timer ----------
@HiltViewModel
class TimerViewModel @Inject constructor(private val repo: TimerRepository) : ViewModel() {
    val endAt: StateFlow<Long?> = repo.endAtMillis.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    private val _invalidInput = MutableStateFlow(false)
    val invalidInput: StateFlow<Boolean> = _invalidInput.asStateFlow()
    private val _error = MutableStateFlow<ActionError?>(null)
    val error: StateFlow<ActionError?> = _error.asStateFlow()

    fun start(minutes: String, seconds: String) {
        val ms = TimerLogic.parseDuration(minutes, seconds)
        if (ms == null) { _invalidInput.value = true; return }
        _invalidInput.value = false
        viewModelScope.launch { _error.value = (repo.start(ms) as? ActionResult.Failure)?.error }
    }

    fun cancel() { viewModelScope.launch { repo.cancel() } }
}

// ---------- Stopwatch ----------
data class StopwatchUi(val running: Boolean = false, val laps: List<Long> = emptyList())

@HiltViewModel
class StopwatchViewModel @Inject constructor(time: TimeSource) : ViewModel() {
    private val watch = Stopwatch(time)
    private val _state = MutableStateFlow(StopwatchUi())
    val state: StateFlow<StopwatchUi> = _state.asStateFlow()

    fun elapsedMillis(): Long = watch.elapsedMillis()
    private fun publish() { _state.value = StopwatchUi(watch.isRunning, watch.laps) }

    fun start() { watch.start(); publish() }
    fun pause() { watch.pause(); publish() }
    fun reset() { watch.reset(); publish() }
    fun lap() { watch.lap(); publish() }
}

// ---------- Voice recorder ----------
data class RecorderUi(
    val recording: Boolean = false,
    val recordings: List<Recording> = emptyList(),
    val error: ActionError? = null
)

@HiltViewModel
class RecorderViewModel @Inject constructor(
    private val repo: RecorderRepository,
    private val time: TimeSource
) : ViewModel() {
    private var startedAt = 0L
    private val _state = MutableStateFlow(RecorderUi(recordings = repo.list()))
    val state: StateFlow<RecorderUi> = _state.asStateFlow()

    fun elapsedMillis(): Long = if (_state.value.recording) time.elapsedMillis() - startedAt else 0L

    fun refresh() { _state.value = _state.value.copy(recordings = repo.list()) }
    fun clearError() { _state.value = _state.value.copy(error = null) }
    fun onMicPermissionDenied() { _state.value = _state.value.copy(error = ActionError.PERMISSION_REQUIRED) }

    fun start() {
        if (_state.value.recording) return
        when (val r = repo.start()) {
            is ActionResult.Success -> { startedAt = time.elapsedMillis(); _state.value = _state.value.copy(recording = true, error = null) }
            is ActionResult.Failure -> _state.value = _state.value.copy(error = r.error)
        }
    }

    fun stop() {
        if (!_state.value.recording) return
        val error = (repo.stop() as? ActionResult.Failure)?.error
        _state.value = RecorderUi(recording = false, recordings = repo.list(), error = error)
    }

    /** Called when the app leaves the foreground: Android restricts background microphone use. */
    fun stopIfRecording() = stop()

    fun delete(name: String) { repo.delete(name); refresh() }

    override fun onCleared() { if (_state.value.recording) repo.stop() }
}
