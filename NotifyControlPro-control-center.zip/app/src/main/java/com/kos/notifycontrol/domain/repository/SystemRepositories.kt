package com.kos.notifycontrol.domain.repository

import com.kos.notifycontrol.domain.model.BatteryState
import kotlinx.coroutines.flow.Flow

interface BatteryRepository {
    /** Event-driven (battery broadcasts), emits the current state first. */
    val state: Flow<BatteryState>
}
