package com.kos.notifycontrol.features.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.RequestResult
import com.kos.notifycontrol.domain.notifications.NotificationActions
import com.kos.notifycontrol.domain.notifications.NotificationItem
import com.kos.notifycontrol.domain.notifications.NotificationStore
import com.kos.notifycontrol.domain.repository.NotificationAccess
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class NotificationCenterUi(
    val accessEnabled: Boolean,
    val connected: Boolean,
    val items: List<NotificationItem>,
    val error: ActionError?
)

@HiltViewModel
class NotificationCenterViewModel @Inject constructor(
    private val store: NotificationStore,
    private val access: NotificationAccess
) : ViewModel() {
    private val accessEnabled = MutableStateFlow(access.isEnabled())
    private val error = MutableStateFlow<ActionError?>(null)

    val state: StateFlow<NotificationCenterUi> =
        combine(accessEnabled, store.connected, store.items, error) { a, c, i, e -> NotificationCenterUi(a, c, i, e) }
            .stateIn(
                viewModelScope, SharingStarted.WhileSubscribed(5_000),
                NotificationCenterUi(accessEnabled.value, store.connected.value, store.items.value, null)
            )

    fun refreshAccess() { accessEnabled.value = access.isEnabled() }
    fun clearError() { error.value = null }

    /** No connected listener = no way to act: reported, never faked. */
    private fun perform(block: (NotificationActions) -> RequestResult) {
        val actions = store.actions
        error.value = if (actions == null) ActionError.FAILED else (block(actions) as? RequestResult.Rejected)?.error
    }

    fun open(key: String) = perform { it.open(key) }
    fun dismiss(key: String) = perform { it.dismiss(key) }
    fun dismissAll() = perform { it.dismissAll() }
}
