package com.kos.notifycontrol.data.system

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import com.kos.notifycontrol.domain.repository.NotificationAccess
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class SystemNotificationAccess @Inject constructor(
    @ApplicationContext private val context: Context
) : NotificationAccess {
    override fun isEnabled(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
}
