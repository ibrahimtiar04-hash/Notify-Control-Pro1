package com.kos.notifycontrol.domain.repository

import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.model.RequestResult
import com.kos.notifycontrol.domain.model.DisplaySnapshot
import com.kos.notifycontrol.domain.model.SoundSnapshot
import com.kos.notifycontrol.domain.model.VolumeStream
import kotlinx.coroutines.flow.Flow

interface DisplayRepository {
    fun read(): DisplaySnapshot
    /** Emits when a watched system display setting changes (ContentObserver). */
    val changes: Flow<Unit>
    /** System brightness 0..255; needs WRITE_SETTINGS grant. Verified by reading back. */
    fun setBrightness(raw: Int): ActionResult
    /** Needs the WRITE_SETTINGS grant. Verified by reading the setting back. */
    fun setAutoRotate(on: Boolean): ActionResult
}

interface SoundRepository {
    fun read(): SoundSnapshot
    /** Emits on ringer-mode and Do Not Disturb changes (system broadcasts). */
    val changes: Flow<Unit>
    fun setVolume(stream: VolumeStream, level: Int): ActionResult
    /**
     * Requests DND on (Priority only) or off. [RequestResult.Accepted] only means the request was accepted;
     * the real state arrives through [changes] / [read].
     */
    fun setDnd(on: Boolean): RequestResult
}
