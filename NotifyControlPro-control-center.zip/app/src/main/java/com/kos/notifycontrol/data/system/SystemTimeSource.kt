package com.kos.notifycontrol.data.system

import android.os.SystemClock
import com.kos.notifycontrol.domain.tools.TimeSource
import javax.inject.Inject

class SystemTimeSource @Inject constructor() : TimeSource {
    override fun elapsedMillis(): Long = SystemClock.elapsedRealtime()
}
