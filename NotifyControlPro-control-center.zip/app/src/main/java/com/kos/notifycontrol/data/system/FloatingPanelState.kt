package com.kos.notifycontrol.data.system

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

/** Process-wide "is the overlay running" flag, set by the service itself (so it is never stale after a kill). */
object FloatingPanelState {
    val running = MutableStateFlow(false)
}

object FloatingPanelLauncher {
    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** False when the overlay permission is missing or Android refused to start the service. */
    fun start(context: Context): Boolean {
        if (!canDrawOverlays(context)) return false
        return try {
            ContextCompat.startForegroundService(context, Intent(context, FloatingPanelService::class.java))
            true
        } catch (e: RuntimeException) {
            false
        }
    }

    fun stop(context: Context) {
        context.stopService(Intent(context, FloatingPanelService::class.java))
    }
}
