package com.kos.notifycontrol.data.system

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowInsets
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.ViewTreeLifecycleOwner
import androidx.lifecycle.ViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.ViewTreeSavedStateRegistryOwner
import com.kos.notifycontrol.MainActivity
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.NotifyControlTheme
import com.kos.notifycontrol.core.designsystem.SettingsIntents
import com.kos.notifycontrol.domain.model.SystemScreen
import com.kos.notifycontrol.domain.model.ThemeMode
import com.kos.notifycontrol.domain.model.TileEffect
import com.kos.notifycontrol.domain.model.TileId
import com.kos.notifycontrol.domain.repository.SettingsRepository
import com.kos.notifycontrol.features.controlcenter.ControlCenterController
import com.kos.notifycontrol.features.controlcenter.ControlCenterControllerFactory
import com.kos.notifycontrol.features.floating.FloatingPanelUi
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/**
 * Foreground service that shows the floating control panel as an overlay window.
 * It runs only while the user turned it on (switch in the app, or the Quick Settings tile) and needs the
 * "display over other apps" permission. The user can stop it from the notification, the switch or the tile.
 */
@AndroidEntryPoint
class FloatingPanelService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    @Inject lateinit var factory: ControlCenterControllerFactory
    @Inject lateinit var settings: SettingsRepository

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val vmStore = ViewModelStore()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var controller: ControlCenterController? = null
    private var view: ComposeView? = null
    private var windowManager: WindowManager? = null
    private lateinit var params: WindowManager.LayoutParams
    private val expanded = mutableStateOf(false)
    private var handleWidthPx = 0
    private var handleHeightPx = 0
    private var topInsetPx = 0

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = vmStore

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedState.performAttach()
        savedState.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
        if (!Settings.canDrawOverlays(this) || !enterForeground()) {
            stopSelf()
            return
        }
        val wm = getSystemService(WindowManager::class.java)
        windowManager = wm
        controller = factory.create(scope, supportsDialogs = false)
        addOverlay(wm, controller!!)
        registry.currentState = Lifecycle.State.RESUMED
        FloatingPanelState.running.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY // never restarted behind the user's back
    }

    override fun onDestroy() {
        controller?.stop()
        scope.cancel()
        view?.let { v -> try { windowManager?.removeView(v) } catch (e: IllegalArgumentException) { /* already removed */ } }
        view = null
        registry.currentState = Lifecycle.State.DESTROYED
        vmStore.clear()
        FloatingPanelState.running.value = false
        super.onDestroy()
    }

    // ---------------- foreground notification ----------------
    private fun enterForeground(): Boolean = try {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.floating_channel_name), NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(getString(R.string.floating_running_title))
            .setContentText(getString(R.string.floating_running_text))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, getString(R.string.floating_stop), stop)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
        true
    } catch (e: RuntimeException) {
        false // e.g. Android refused to let this start in the foreground
    }

    // ---------------- overlay window ----------------
    private fun statusBarHeightPx(wm: WindowManager): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            wm.currentWindowMetrics.windowInsets.getInsets(WindowInsets.Type.statusBars()).top
        else (24 * resources.displayMetrics.density).toInt()

    private fun addOverlay(wm: WindowManager, ctl: ControlCenterController) {
        val density = resources.displayMetrics.density
        handleWidthPx = (112 * density).toInt()
        handleHeightPx = (28 * density).toInt()
        topInsetPx = statusBarHeightPx(wm)
        params = WindowManager.LayoutParams(
            handleWidthPx, handleHeightPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = topInsetPx // just below the status bar: the system pull-down area stays the system's
        }
        val cv = ComposeView(this)
        ViewTreeLifecycleOwner.set(cv, this)
        ViewTreeSavedStateRegistryOwner.set(cv, this)
        ViewTreeViewModelStoreOwner.set(cv, this)
        cv.setContent {
            val mode by settings.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
            val state by ctl.state.collectAsState()
            NotifyControlTheme(mode, state.accent) {
                FloatingPanelUi(
                    state = state,
                    expanded = expanded.value,
                    topInsetDp = topInsetPx / density,
                    onExpand = { setExpanded(true) },
                    onCollapse = { setExpanded(false) },
                    onTile = ::onTile,
                    onBrightness = ctl::setBrightness,
                    onVolume = ctl::setVolume,
                    onGrantWriteSettings = { launch(SettingsIntents.of(SystemScreen.WRITE_SETTINGS, packageName)) },
                    onOpenApp = { openApp() }
                )
            }
        }
        wm.addView(cv, params)
        view = cv
    }

    private fun setExpanded(value: Boolean) {
        if (expanded.value == value) return
        expanded.value = value
        val v = view ?: return
        params.apply {
            if (value) { width = WindowManager.LayoutParams.MATCH_PARENT; height = WindowManager.LayoutParams.MATCH_PARENT; y = 0 }
            else { width = handleWidthPx; height = handleHeightPx; y = topInsetPx }
        }
        windowManager?.updateViewLayout(v, params)
        if (value) controller?.start() else controller?.stop()
        if (value) controller?.refresh()
    }

    private fun onTile(id: TileId) {
        when (val effect = controller?.onTileClick(id)) {
            is TileEffect.Launch -> launch(SettingsIntents.of(effect.screen, packageName))
            // The overlay cannot show system dialogs: it was created with supportsDialogs = false.
            TileEffect.RequestBluetoothEnable, TileEffect.RequestBluetoothPermission ->
                launch(SettingsIntents.of(SystemScreen.BLUETOOTH_SETTINGS, packageName))
            else -> Unit
        }
    }

    /** Starting an activity from here is allowed because the app is showing an overlay window. */
    private fun launch(intent: Intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            setExpanded(false)
        } catch (e: RuntimeException) {
            // no activity can handle it, or Android refused: the panel stays open
        }
    }

    private fun openApp() {
        packageManager.getLaunchIntentForPackage(packageName)?.let { launch(it) }
    }

    companion object {
        const val ACTION_STOP = "com.kos.notifycontrol.action.STOP_FLOATING"
        private const val CHANNEL = "floating_panel"
        private const val NOTIFICATION_ID = 1002
    }
}
