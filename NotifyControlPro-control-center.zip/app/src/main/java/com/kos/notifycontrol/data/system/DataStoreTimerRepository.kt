package com.kos.notifycontrol.data.system

import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.repository.TimerRepository
import com.kos.notifycontrol.domain.tools.TimerCoordinator
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow

/** Singleton on purpose: one TimerCoordinator means one lock for start / cancel / restore. */
@Singleton
class DataStoreTimerRepository @Inject constructor(
    store: DataStoreTimerStore,
    alarm: AlarmManagerTimerAlarm
) : TimerRepository {
    private val coordinator = TimerCoordinator(store, alarm) { System.currentTimeMillis() }

    override val endAtMillis: Flow<Long?> = coordinator.endAtMillis
    override suspend fun start(durationMs: Long): ActionResult = coordinator.start(durationMs)
    override suspend fun cancel() = coordinator.cancel()
    override suspend fun restore() = coordinator.restore()
}
