package com.kos.notifycontrol.features.customize

import android.Manifest
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.drawable.Icon as PlatformIcon
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.*
import com.kos.notifycontrol.data.system.FloatingPanelLauncher
import com.kos.notifycontrol.data.system.FloatingPanelState
import com.kos.notifycontrol.data.system.FloatingPanelTileService
import com.kos.notifycontrol.domain.model.AccentColor
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.SystemScreen
import com.kos.notifycontrol.features.controlcenter.tileLabel
import kotlin.math.roundToInt

@Composable
fun CustomizeScreen(modifier: Modifier = Modifier, vm: CustomizeViewModel = hiltViewModel()) {
    val custom by vm.state.collectAsStateWithLifecycle()
    val running by FloatingPanelState.running.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var needsOverlayPermission by remember { mutableStateOf(false) }
    var startFailed by remember { mutableStateOf(false) }
    var launchFailed by remember { mutableStateOf(false) }

    fun startFloating() {
        if (!FloatingPanelLauncher.canDrawOverlays(context)) { needsOverlayPermission = true; return }
        needsOverlayPermission = false
        startFailed = !FloatingPanelLauncher.start(context)
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        startFloating() // the service runs even if the (foreground) notification is not allowed
    }
    fun requestStart() {
        val needs = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needs) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else startFloating()
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(stringResource(R.string.customize_title), style = MaterialTheme.typography.headlineMedium)

        SectionCard(stringResource(R.string.floating_title)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(if (running) R.string.on else R.string.off))
                Switch(checked = running, onCheckedChange = { on -> if (on) requestStart() else FloatingPanelLauncher.stop(context) })
            }
            Text(stringResource(R.string.floating_note), style = MaterialTheme.typography.bodySmall)
            if (needsOverlayPermission) {
                Text(stringResource(R.string.permission_required), color = MaterialTheme.colorScheme.error)
                Text(stringResource(R.string.overlay_permission_explain), style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    launchFailed = !context.launchSettings(SettingsIntents.of(SystemScreen.OVERLAY_PERMISSION, context.packageName))
                }) { Text(stringResource(R.string.grant_permission)) }
            }
            if (startFailed) ErrorText(ActionError.FAILED)
        }

        SectionCard(stringResource(R.string.qs_tile_title)) {
            Text(stringResource(R.string.qs_tile_note), style = MaterialTheme.typography.bodySmall)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                OutlinedButton(onClick = { requestAddTile(context) }) { Text(stringResource(R.string.qs_tile_add)) }
            }
        }

        SectionCard(stringResource(R.string.customize_tiles)) {
            custom.slots.forEachIndexed { index, slot ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = slot.enabled, onCheckedChange = { vm.setEnabled(slot.id, it) })
                    Text(stringResource(tileLabel(slot.id)), Modifier.weight(1f).padding(horizontal = 12.dp))
                    IconButton(onClick = { vm.moveUp(slot.id) }, enabled = index > 0) {
                        Icon(Icons.Filled.KeyboardArrowUp, contentDescription = stringResource(R.string.move_up))
                    }
                    IconButton(onClick = { vm.moveDown(slot.id) }, enabled = index < custom.slots.lastIndex) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = stringResource(R.string.move_down))
                    }
                }
            }
        }

        SectionCard(stringResource(R.string.customize_accent)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AccentColor.entries.forEach { a ->
                    val name = stringResource(accentName(a))
                    Box(
                        Modifier.size(40.dp)
                            .background(Color(a.argb), CircleShape)
                            .then(if (a == custom.accent) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                            .semantics { contentDescription = name }
                            .clickable(role = Role.RadioButton) { vm.setAccent(a) }
                    )
                }
            }
        }

        SectionCard(stringResource(R.string.customize_opacity)) {
            var drag by remember(custom.panelAlpha) { mutableStateOf<Float?>(null) }
            val shown = drag ?: custom.panelAlpha
            LabeledRow(stringResource(R.string.customize_opacity), stringResource(R.string.percent_fmt, (shown * 100).roundToInt()))
            Slider(
                value = shown, onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { vm.setPanelAlpha(it) }; drag = null },
                valueRange = 0.5f..1f
            )
        }

        OutlinedButton(onClick = { vm.reset() }) { Text(stringResource(R.string.customize_reset)) }
        if (launchFailed) ErrorText(ActionError.UNSUPPORTED)
    }
}

private fun accentName(a: AccentColor) = when (a) {
    AccentColor.BLUE -> R.string.accent_blue
    AccentColor.CYAN -> R.string.accent_cyan
    AccentColor.GREEN -> R.string.accent_green
    AccentColor.ORANGE -> R.string.accent_orange
    AccentColor.PINK -> R.string.accent_pink
    AccentColor.PURPLE -> R.string.accent_purple
}

/** Android 13+: asks the system to offer adding this app's Quick Settings tile (the user confirms). */
private fun requestAddTile(context: android.content.Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
    val sbm = context.getSystemService(StatusBarManager::class.java) ?: return
    sbm.requestAddTileService(
        ComponentName(context, FloatingPanelTileService::class.java),
        context.getString(R.string.qs_tile_label),
        PlatformIcon.createWithResource(context, R.drawable.ic_tile_panel),
        context.mainExecutor
    ) { _ -> }
}
