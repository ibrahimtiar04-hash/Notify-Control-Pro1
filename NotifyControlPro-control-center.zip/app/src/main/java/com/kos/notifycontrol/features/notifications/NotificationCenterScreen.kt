package com.kos.notifycontrol.features.notifications

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.text.format.DateUtils
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kos.notifycontrol.R
import com.kos.notifycontrol.core.designsystem.ErrorText
import com.kos.notifycontrol.core.designsystem.SettingsIntents
import com.kos.notifycontrol.core.designsystem.launchSettings
import com.kos.notifycontrol.data.system.NotifyListenerService
import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.notifications.NotificationItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun NotificationCenterScreen(modifier: Modifier = Modifier, vm: NotificationCenterViewModel = hiltViewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var launchFailed by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        vm.refreshAccess()
        // Enabled in settings but not connected (e.g. the process was restarted): ask the system to rebind.
        if (ui.accessEnabled && !ui.connected) {
            runCatching { NotificationListenerService.requestRebind(ComponentName(context, NotifyListenerService::class.java)) }
        }
    }

    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.notifications_title), style = MaterialTheme.typography.headlineMedium)
        when {
            !ui.accessEnabled -> Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.permission_required), color = MaterialTheme.colorScheme.error)
                    Text(stringResource(R.string.notifications_access_explain), style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { launchFailed = !context.launchSettings(SettingsIntents.notificationListenerAccess()) }) {
                        Text(stringResource(R.string.enable_notification_access))
                    }
                }
            }
            !ui.connected -> Text(stringResource(R.string.notifications_connecting))
            ui.items.isEmpty() -> Text(stringResource(R.string.no_notifications))
            else -> {
                OutlinedButton(onClick = { vm.dismissAll() }, enabled = ui.items.any { it.isClearable }) {
                    Text(stringResource(R.string.clear_all))
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ui.items, key = { it.key }) { item ->
                        NotificationCard(
                            item,
                            onOpen = { vm.open(item.key) },
                            onManage = { launchFailed = !context.launchSettings(SettingsIntents.appNotificationSettings(item.packageName)) },
                            onDismiss = { vm.dismiss(item.key) }
                        )
                    }
                }
            }
        }
        ErrorText(ui.error)
        if (launchFailed) ErrorText(ActionError.UNSUPPORTED)
    }
}

@Composable
private fun NotificationCard(item: NotificationItem, onOpen: () -> Unit, onManage: () -> Unit, onDismiss: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppIcon(item.packageName)
                Column(Modifier.weight(1f)) {
                    Text(item.appName, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    Text(
                        DateUtils.getRelativeTimeSpanString(item.postTime, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            item.title?.let { Text(it, style = MaterialTheme.typography.titleSmall) }
            item.text?.let { Text(it, style = MaterialTheme.typography.bodyMedium, maxLines = 4) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onOpen) { Text(stringResource(R.string.open_notification)) }
                TextButton(onClick = onManage) { Text(stringResource(R.string.manage_notification)) }
                if (item.isClearable) TextButton(onClick = onDismiss) { Text(stringResource(R.string.dismiss_notification)) }
            }
        }
    }
}

@Composable
private fun AppIcon(pkg: String) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) {
            try { context.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (e: Exception) { null }
        }
    }
    bitmap?.let { Image(it, contentDescription = null, modifier = Modifier.size(36.dp)) } ?: Spacer(Modifier.size(36.dp))
}
