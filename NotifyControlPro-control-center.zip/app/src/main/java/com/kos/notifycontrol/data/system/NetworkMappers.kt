package com.kos.notifycontrol.data.system

import android.bluetooth.BluetoothAdapter
import android.net.wifi.WifiManager
import com.kos.notifycontrol.domain.model.ActiveTransport
import com.kos.notifycontrol.domain.model.ToggleState

/** Pure conversions of raw system values; unit-testable on the JVM. */
object NetworkMappers {
    fun wifi(state: Int): ToggleState = when (state) {
        WifiManager.WIFI_STATE_ENABLED -> ToggleState.ON
        WifiManager.WIFI_STATE_DISABLED -> ToggleState.OFF
        WifiManager.WIFI_STATE_ENABLING -> ToggleState.TURNING_ON
        WifiManager.WIFI_STATE_DISABLING -> ToggleState.TURNING_OFF
        else -> ToggleState.UNKNOWN
    }

    fun bluetooth(state: Int): ToggleState = when (state) {
        BluetoothAdapter.STATE_ON -> ToggleState.ON
        BluetoothAdapter.STATE_OFF -> ToggleState.OFF
        BluetoothAdapter.STATE_TURNING_ON -> ToggleState.TURNING_ON
        BluetoothAdapter.STATE_TURNING_OFF -> ToggleState.TURNING_OFF
        else -> ToggleState.UNKNOWN
    }

    /** [hasNetwork] false means there is no active network at all. */
    fun transport(hasNetwork: Boolean, wifi: Boolean, cellular: Boolean, ethernet: Boolean): ActiveTransport = when {
        !hasNetwork -> ActiveTransport.NONE
        wifi -> ActiveTransport.WIFI
        cellular -> ActiveTransport.CELLULAR
        ethernet -> ActiveTransport.ETHERNET
        else -> ActiveTransport.OTHER
    }

    /** Settings.Global.AIRPLANE_MODE_ON: 1 on, 0 off, anything else = not readable. */
    fun airplane(raw: Int): Boolean? = when (raw) { 1 -> true; 0 -> false; else -> null }
}
