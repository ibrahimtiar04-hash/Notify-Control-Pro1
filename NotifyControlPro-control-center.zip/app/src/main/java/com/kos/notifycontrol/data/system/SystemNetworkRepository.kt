package com.kos.notifycontrol.data.system

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.kos.notifycontrol.domain.model.ActiveTransport
import com.kos.notifycontrol.domain.model.NetworkSnapshot
import com.kos.notifycontrol.domain.model.ToggleState
import com.kos.notifycontrol.domain.repository.NetworkRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

@Singleton
class SystemNetworkRepository @Inject constructor(
    @ApplicationContext private val context: Context
) : NetworkRepository {
    private val pm = context.packageManager
    private val wifiManager = context.getSystemService(WifiManager::class.java)
    private val btAdapter: BluetoothAdapter? = context.getSystemService(BluetoothManager::class.java)?.adapter
    private val cm = context.getSystemService(ConnectivityManager::class.java)

    private fun wifiState(): ToggleState? {
        if (!pm.hasSystemFeature(PackageManager.FEATURE_WIFI) || wifiManager == null) return null
        return try {
            NetworkMappers.wifi(wifiManager.wifiState)
        } catch (e: SecurityException) {
            ToggleState.UNKNOWN
        }
    }

    private fun bluetoothState(): ToggleState? {
        if (!pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)) return null
        val adapter = btAdapter ?: return null
        return try {
            NetworkMappers.bluetooth(adapter.state)
        } catch (e: SecurityException) {
            // On Android 12+ this means BLUETOOTH_CONNECT is missing: the UI offers to request it.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ToggleState.PERMISSION_REQUIRED
            else ToggleState.UNKNOWN
        }
    }

    private fun airplane(): Boolean? = try {
        NetworkMappers.airplane(Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, -1))
    } catch (e: SecurityException) {
        null
    }

    /** Returns (transport, internetValidated). Failures yield UNKNOWN, never NONE. */
    private fun activeNetwork(): Pair<ActiveTransport, Boolean> = try {
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        when {
            network == null -> ActiveTransport.NONE to false
            caps == null -> ActiveTransport.UNKNOWN to false
            else -> NetworkMappers.transport(
                hasNetwork = true,
                wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI),
                cellular = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR),
                ethernet = caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            ) to caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }
    } catch (e: SecurityException) {
        ActiveTransport.UNKNOWN to false
    }

    override fun read(): NetworkSnapshot {
        val (transport, validated) = activeNetwork()
        return NetworkSnapshot(
            wifi = wifiState(),
            bluetooth = bluetoothState(),
            airplaneMode = airplane(),
            transport = transport,
            internetValidated = validated
        )
    }

    override val changes: Flow<Unit> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) { trySend(Unit) }
        }
        val filter = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(Unit) }
            override fun onLost(network: Network) { trySend(Unit) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { trySend(Unit) }
        }
        // Registration can throw (SecurityException, TooManyRequestsException): keep the broadcasts working.
        val callbackRegistered = try {
            cm.registerDefaultNetworkCallback(callback); true
        } catch (e: RuntimeException) {
            false
        }
        awaitClose {
            context.unregisterReceiver(receiver)
            if (callbackRegistered) cm.unregisterNetworkCallback(callback)
        }
    }
}
