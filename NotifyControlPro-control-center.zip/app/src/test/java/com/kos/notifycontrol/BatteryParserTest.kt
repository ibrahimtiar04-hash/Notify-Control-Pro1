package com.kos.notifycontrol

import android.os.BatteryManager
import com.kos.notifycontrol.data.system.BatteryParser
import com.kos.notifycontrol.domain.model.ChargingStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BatteryParserTest {
    @Test fun levelIsPercentOfScale() {
        assertEquals(50, BatteryParser.parse(50, 100, BatteryManager.BATTERY_STATUS_CHARGING, null).levelPercent)
        assertEquals(25, BatteryParser.parse(1, 4, BatteryManager.BATTERY_STATUS_CHARGING, null).levelPercent)
    }
    @Test fun invalidLevelOrScaleIsNull() {
        assertNull(BatteryParser.parse(-1, 100, BatteryManager.BATTERY_STATUS_FULL, null).levelPercent)
        assertNull(BatteryParser.parse(50, -1, BatteryManager.BATTERY_STATUS_FULL, null).levelPercent)
        assertNull(BatteryParser.parse(50, 0, BatteryManager.BATTERY_STATUS_FULL, null).levelPercent)
    }
    @Test fun statusMapping() {
        assertEquals(ChargingStatus.CHARGING, BatteryParser.parse(1, 2, BatteryManager.BATTERY_STATUS_CHARGING, null).charging)
        assertEquals(ChargingStatus.DISCHARGING, BatteryParser.parse(1, 2, BatteryManager.BATTERY_STATUS_DISCHARGING, null).charging)
        assertEquals(ChargingStatus.FULL, BatteryParser.parse(1, 2, BatteryManager.BATTERY_STATUS_FULL, null).charging)
        assertEquals(ChargingStatus.NOT_CHARGING, BatteryParser.parse(1, 2, BatteryManager.BATTERY_STATUS_NOT_CHARGING, null).charging)
        assertEquals(ChargingStatus.UNKNOWN, BatteryParser.parse(1, 2, BatteryManager.BATTERY_STATUS_UNKNOWN, null).charging)
        assertEquals(ChargingStatus.UNKNOWN, BatteryParser.parse(1, 2, 999, null).charging)
    }
    @Test fun temperatureTenthsToCelsiusOrNull() {
        assertEquals(31.5f, BatteryParser.parse(1, 2, 2, 315).temperatureCelsius!!, 0.001f)
        assertNull(BatteryParser.parse(1, 2, 2, null).temperatureCelsius)
    }
}
