package com.kos.notifycontrol

import android.bluetooth.BluetoothAdapter
import android.net.wifi.WifiManager
import com.kos.notifycontrol.data.system.NetworkMappers
import com.kos.notifycontrol.domain.model.ActiveTransport
import com.kos.notifycontrol.domain.model.ToggleState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NetworkTests {
    @Test fun wifiMapping() {
        assertEquals(ToggleState.ON, NetworkMappers.wifi(WifiManager.WIFI_STATE_ENABLED))
        assertEquals(ToggleState.OFF, NetworkMappers.wifi(WifiManager.WIFI_STATE_DISABLED))
        assertEquals(ToggleState.TURNING_ON, NetworkMappers.wifi(WifiManager.WIFI_STATE_ENABLING))
        assertEquals(ToggleState.TURNING_OFF, NetworkMappers.wifi(WifiManager.WIFI_STATE_DISABLING))
        assertEquals(ToggleState.UNKNOWN, NetworkMappers.wifi(WifiManager.WIFI_STATE_UNKNOWN))
    }

    @Test fun bluetoothMapping() {
        assertEquals(ToggleState.ON, NetworkMappers.bluetooth(BluetoothAdapter.STATE_ON))
        assertEquals(ToggleState.OFF, NetworkMappers.bluetooth(BluetoothAdapter.STATE_OFF))
        assertEquals(ToggleState.TURNING_ON, NetworkMappers.bluetooth(BluetoothAdapter.STATE_TURNING_ON))
        assertEquals(ToggleState.TURNING_OFF, NetworkMappers.bluetooth(BluetoothAdapter.STATE_TURNING_OFF))
        assertEquals(ToggleState.UNKNOWN, NetworkMappers.bluetooth(-5))
    }

    @Test fun transportPriorityAndNone() {
        assertEquals(ActiveTransport.NONE, NetworkMappers.transport(false, true, true, true))
        assertEquals(ActiveTransport.WIFI, NetworkMappers.transport(true, true, true, false))
        assertEquals(ActiveTransport.CELLULAR, NetworkMappers.transport(true, false, true, false))
        assertEquals(ActiveTransport.ETHERNET, NetworkMappers.transport(true, false, false, true))
        assertEquals(ActiveTransport.OTHER, NetworkMappers.transport(true, false, false, false))
    }

    @Test fun airplaneReadsOnlyZeroOrOne() {
        assertEquals(true, NetworkMappers.airplane(1))
        assertEquals(false, NetworkMappers.airplane(0))
        assertNull(NetworkMappers.airplane(-1))
    }
}
