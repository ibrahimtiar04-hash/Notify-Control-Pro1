package com.kos.notifycontrol

import com.kos.notifycontrol.domain.controlcenter.DndStatus
import com.kos.notifycontrol.domain.controlcenter.DndUi
import com.kos.notifycontrol.domain.model.*
import com.kos.notifycontrol.domain.tools.*
import java.io.IOException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

private class R3Source(
    var feature: () -> Boolean = { true },
    var ids: () -> List<String> = { emptyList() },
    var flash: (String) -> Boolean = { false },
    var back: (String) -> Boolean = { false }
) : TorchSource {
    override fun hasFlashFeature() = feature()
    override fun cameraIds() = ids()
    override fun hasFlash(id: String) = flash(id)
    override fun isBackFacing(id: String) = back(id)
}

private class R3Store : TimerStore {
    val flow = MutableStateFlow<Long?>(null)
    var gate: CompletableDeferred<Unit>? = null
    var failSave = false
    var failClear = false
    override val endAt: Flow<Long?> = flow
    override suspend fun load(): Long? { gate?.await(); return flow.value }
    override suspend fun save(endAt: Long) { if (failSave) throw IOException("save"); flow.value = endAt }
    override suspend fun clear() { if (failClear) throw IOException("clear"); flow.value = null }
}

private class R3Alarm : TimerAlarm {
    var scheduledAt: Long? = null
    var scheduleCalls = 0
    var failSchedule = false
    override fun schedule(endAt: Long) {
        if (failSchedule) throw SecurityException("no alarm")
        scheduleCalls++
        scheduledAt = endAt
    }
    override fun cancel() { scheduledAt = null }
}

// ---------------- DND UI: UNKNOWN is never OFF ----------------
class DndUiTests {
    @Test fun unknownFilterIsUnknownAndToggleDisabledEvenWithAccess() {
        val ui = DndUi.from(DndState(PolicyAccess.GRANTED, DndFilter.UNKNOWN))
        assertEquals(DndStatus.UNKNOWN, ui.status)
        assertNotEquals(DndStatus.OFF, ui.status)
        assertFalse(ui.toggleEnabled)
    }

    @Test fun allIsOffAndToggleEnabledOnlyWithAccess() {
        assertEquals(DndStatus.OFF, DndUi.from(DndState(PolicyAccess.GRANTED, DndFilter.ALL)).status)
        assertTrue(DndUi.from(DndState(PolicyAccess.GRANTED, DndFilter.ALL)).toggleEnabled)
        assertFalse(DndUi.from(DndState(PolicyAccess.NOT_GRANTED, DndFilter.ALL)).toggleEnabled)
        assertFalse(DndUi.from(DndState(PolicyAccess.UNKNOWN, DndFilter.ALL)).toggleEnabled)
    }

    @Test fun restrictiveFiltersAreOn() {
        listOf(DndFilter.PRIORITY, DndFilter.ALARMS_ONLY, DndFilter.NONE).forEach {
            assertEquals(DndStatus.ON, DndUi.from(DndState(PolicyAccess.GRANTED, it)).status)
        }
    }

    @Test fun unknownStatusStaysUnknownWhateverTheAccess() {
        PolicyAccess.entries.forEach {
            val ui = DndUi.from(DndState(it, DndFilter.UNKNOWN))
            assertEquals(DndStatus.UNKNOWN, ui.status)
            assertFalse(ui.toggleEnabled)
        }
    }
}

class VolumeAvailabilityTests {
    @Test fun refusedFixedVolumeReadIsUnknownNotFixed() {
        assertEquals(VolumeAvailability.UNKNOWN, VolumeAvailability.from(null))
        assertEquals(VolumeAvailability.FIXED, VolumeAvailability.from(true))
        assertEquals(VolumeAvailability.AVAILABLE, VolumeAvailability.from(false))
    }
}

class TorchResolverTests {
    @Test fun noFlashFeatureOrNoFlashCameraIsNone() {
        assertEquals(TorchLookup.None, TorchResolver.resolve(R3Source(feature = { false })))
        assertEquals(TorchLookup.None, TorchResolver.resolve(R3Source(ids = { listOf("0", "1") }, flash = { false })))
        assertEquals(TorchLookup.None, TorchResolver.resolve(R3Source(ids = { emptyList() })))
    }

    @Test fun backFacingFlashCameraIsPreferredElseFirstWithFlash() {
        assertEquals(
            TorchLookup.Found("1"),
            TorchResolver.resolve(R3Source(ids = { listOf("0", "1") }, flash = { true }, back = { it == "1" }))
        )
        assertEquals(
            TorchLookup.Found("2"),
            TorchResolver.resolve(R3Source(ids = { listOf("0", "2") }, flash = { it == "2" }, back = { false }))
        )
    }

    @Test fun anyServiceExceptionIsFailedNeverNone() {
        val errors = listOf<Exception>(
            RuntimeException("runtime"), IllegalStateException("state"), IllegalArgumentException("arg"),
            SecurityException("denied"), Exception("camera access (checked-style)")
        )
        errors.forEach { e ->
            val inFeature = TorchResolver.resolve(R3Source(feature = { throw e }))
            val inIds = TorchResolver.resolve(R3Source(ids = { throw e }))
            val inFlash = TorchResolver.resolve(R3Source(ids = { listOf("0") }, flash = { throw e }))
            val inBack = TorchResolver.resolve(R3Source(ids = { listOf("0") }, flash = { true }, back = { throw e }))
            listOf(inFeature, inIds, inFlash, inBack).forEach {
                assertEquals("for ${e.message}", TorchLookup.Failed, it)
                assertNotEquals(TorchLookup.None, it)
            }
        }
    }
}

// ---------------- timer coordinator: races ----------------
@OptIn(ExperimentalCoroutinesApi::class)
class TimerCoordinatorTests {
    private val store = R3Store()
    private val alarm = R3Alarm()
    private fun coordinator(now: Long = 1_000) = TimerCoordinator(store, alarm) { now }

    @Test fun cancelArrivingWhileRestoreIsInFlightLeavesNoAlarm() = runTest {
        store.flow.value = 10_000
        val gate = CompletableDeferred<Unit>()
        store.gate = gate
        val c = coordinator()
        launch { c.restore() }
        runCurrent()                        // restore holds the lock and waits on storage
        launch { c.cancel() }
        runCurrent()                        // cancel is queued behind it
        assertNull(alarm.scheduledAt)
        gate.complete(Unit)
        advanceUntilIdle()
        assertNull("old alarm must not survive a cancel", alarm.scheduledAt)
        assertNull(store.flow.value)
    }

    @Test fun cancelBeforeRestoreMeansNothingIsRescheduled() = runTest {
        store.flow.value = 10_000
        val c = coordinator()
        c.cancel()
        c.restore()
        assertEquals(0, alarm.scheduleCalls)
        assertNull(alarm.scheduledAt)
    }

    @Test fun startThenCancelLeavesNoTimerAndNoAlarm() = runTest {
        val c = coordinator()
        assertEquals(ActionResult.Success(0), c.start(5_000))
        assertEquals(6_000L, alarm.scheduledAt)
        assertEquals(6_000L, store.flow.value)
        c.cancel()
        assertNull(alarm.scheduledAt)
        assertNull(store.flow.value)
        c.restore()
        assertNull(alarm.scheduledAt)
    }

    @Test fun restoreRearmsOnlyAFutureSavedTimer() = runTest {
        val c = coordinator(now = 1_000)
        c.restore(); assertEquals(0, alarm.scheduleCalls)            // nothing saved
        store.flow.value = 500; c.restore(); assertEquals(0, alarm.scheduleCalls)    // already finished
        store.flow.value = 1_000; c.restore(); assertEquals(0, alarm.scheduleCalls)   // finishes exactly now
        store.flow.value = 9_000; c.restore()
        assertEquals(9_000L, alarm.scheduledAt)
    }

    @Test fun failedSaveLeavesNoTimerRunning() = runTest {
        store.failSave = true
        assertEquals(ActionResult.Failure(ActionError.FAILED), coordinator().start(5_000))
        assertNull(alarm.scheduledAt)
        assertNull(store.flow.value)
    }

    @Test fun refusedAlarmLeavesNoTimerRunning() = runTest {
        alarm.failSchedule = true
        assertEquals(ActionResult.Failure(ActionError.PERMISSION_REQUIRED), coordinator().start(5_000))
        assertNull(alarm.scheduledAt)
        assertNull(store.flow.value)
    }

    @Test fun cancelThatCannotEraseStorageIsNotUndoneByRestore() = runTest {
        store.flow.value = 10_000
        store.failClear = true
        val c = coordinator()
        c.cancel()                          // clear() throws; must not crash
        c.restore()
        assertEquals("a cancelled timer must not be re-armed", 0, alarm.scheduleCalls)
        assertNull(alarm.scheduledAt)
    }

    @Test fun startAfterAFailedCancelWorksNormally() = runTest {
        store.flow.value = 10_000
        store.failClear = true
        val c = coordinator()
        c.cancel()
        store.failClear = false
        assertEquals(ActionResult.Success(0), c.start(5_000))
        c.restore()
        assertEquals(6_000L, alarm.scheduledAt)
        assertEquals(6_000L, store.flow.value)
    }

    @Test fun concurrentStartsAreSerializedAndConsistent() = runTest {
        val c = coordinator()
        launch { c.start(1_000) }
        launch { c.start(2_000) }
        advanceUntilIdle()
        assertEquals("alarm and saved time must agree", store.flow.value, alarm.scheduledAt)
        assertEquals(3_000L, store.flow.value)
    }
}
