package com.kos.notifycontrol

import com.kos.notifycontrol.domain.controlcenter.TileStates
import com.kos.notifycontrol.domain.model.*
import com.kos.notifycontrol.domain.repository.*
import com.kos.notifycontrol.features.controlcenter.ControlCenterController
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

// ---------------- fakes (tests only) ----------------
private class CCNetwork(var snap: NetworkSnapshot) : NetworkRepository {
    val events = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    override fun read() = snap
    override val changes: Flow<Unit> = events
}

private class CCSound(var snap: SoundSnapshot) : SoundRepository {
    var volumeResult: ActionResult? = null
    var dndResult: RequestResult = RequestResult.Accepted
    var dndCalls = 0
    var lastDnd: Boolean? = null
    override fun read() = snap
    override val changes: Flow<Unit> = MutableSharedFlow()
    override fun setVolume(stream: VolumeStream, level: Int): ActionResult {
        val r = volumeResult ?: ActionResult.Success(level)
        if (r is ActionResult.Success) snap = snap.copy(volumes = snap.volumes.map { if (it.stream == stream) it.copy(current = level) else it })
        return r
    }
    override fun setDnd(on: Boolean): RequestResult { dndCalls++; lastDnd = on; return dndResult }
}

private class CCDisplay(var snap: DisplaySnapshot) : DisplayRepository {
    var brightnessResult: ActionResult? = null
    var rotateResult: ActionResult? = null
    var brightnessCalls = 0
    var rotateCalls = 0
    var lastRotate: Boolean? = null
    override fun read() = snap
    override val changes: Flow<Unit> = MutableSharedFlow()
    override fun setBrightness(raw: Int): ActionResult {
        brightnessCalls++
        val r = brightnessResult ?: ActionResult.Success(raw)
        if (r is ActionResult.Success) snap = snap.copy(brightness = raw)
        return r
    }
    override fun setAutoRotate(on: Boolean): ActionResult {
        rotateCalls++; lastRotate = on
        val r = rotateResult ?: ActionResult.Success(if (on) 1 else 0)
        if (r is ActionResult.Success) snap = snap.copy(autoRotate = on)
        return r
    }
}

private class CCFlash : FlashlightRepository {
    val s = MutableStateFlow(FlashlightState.OFF)
    var result: RequestResult = RequestResult.Accepted
    var calls = 0
    var last: Boolean? = null
    override val state: Flow<FlashlightState> = s
    override fun setTorch(on: Boolean): RequestResult { calls++; last = on; return result }
}

private class CCBattery : BatteryRepository {
    val s = MutableStateFlow(BatteryState(80, ChargingStatus.CHARGING, null))
    override val state: Flow<BatteryState> = s
}

private class CCClock : ClockRepository {
    val s = MutableStateFlow(ZonedDateTime.of(2026, 11, 26, 10, 5, 0, 0, ZoneId.of("UTC")))
    override val now: Flow<ZonedDateTime> = s
}

private class CCLocation(var value: Boolean? = true) : LocationRepository {
    val events = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    override fun read() = value
    override val changes: Flow<Unit> = events
}

private class CCCustomization(initial: Customization = Customization.default()) : CustomizationRepository {
    val flow = MutableStateFlow(initial)
    override val customization: Flow<Customization> = flow
    override suspend fun setAccent(accent: AccentColor) { flow.value = flow.value.copy(accent = accent) }
    override suspend fun setPanelAlpha(alpha: Float) { flow.value = flow.value.copy(panelAlpha = Customization.clampAlpha(alpha)) }
    override suspend fun setSlots(slots: List<TileSlot>) { flow.value = flow.value.copy(slots = slots) }
    override suspend fun reset() { flow.value = Customization.default() }
}

private fun net(
    wifi: ToggleState? = ToggleState.ON, bt: ToggleState? = ToggleState.OFF, airplane: Boolean? = false
) = NetworkSnapshot(wifi, bt, airplane, ActiveTransport.WIFI, true)

private fun snd(
    dnd: DndState = DndState(PolicyAccess.GRANTED, DndFilter.ALL),
    availability: VolumeAvailability = VolumeAvailability.AVAILABLE
) = SoundSnapshot(
    listOf(
        VolumeState(VolumeStream.MEDIA, 5, 0, 15), VolumeState(VolumeStream.RING, 3, 0, 7),
        VolumeState(VolumeStream.ALARM, 2, 0, 7)
    ),
    RingerMode.NORMAL, dnd, availability
)

private fun dsp(canWrite: Boolean = true, autoRotate: Boolean? = true, brightness: Int? = 100) =
    DisplaySnapshot(brightness, false, canWrite, 30_000, autoRotate, 1.0f, false)

private class Rig(
    val network: CCNetwork = CCNetwork(net()),
    val sound: CCSound = CCSound(snd()),
    val display: CCDisplay = CCDisplay(dsp()),
    val flash: CCFlash = CCFlash(),
    val battery: CCBattery = CCBattery(),
    val clock: CCClock = CCClock(),
    val location: CCLocation = CCLocation(),
    val custom: CCCustomization = CCCustomization()
) {
    fun controller(scope: CoroutineScope, supportsDialogs: Boolean = true) = ControlCenterController(
        scope, network, sound, display, flash, battery, clock, location, custom, supportsDialogs
    )
}

private fun ControlCenterController.status(id: TileId) = state.value.tiles.first { it.id == id }.status

@OptIn(ExperimentalCoroutinesApi::class)
class ControlCenterControllerTests {

    // ---------------- state comes from real reads ----------------
    @Test fun tilesReflectTheSystemAndFlashlightIsUnknownUntilTheCallbackReports() = runTest {
        val c = Rig().controller(backgroundScope)
        assertEquals(TileId.entries.toList(), c.state.value.tiles.map { it.id })
        assertEquals(TileStatus.ON, c.status(TileId.WIFI))
        assertEquals(TileStatus.OFF, c.status(TileId.BLUETOOTH))
        assertEquals(TileStatus.UNKNOWN, c.status(TileId.FLASHLIGHT)) // never shown as OFF before the callback
        assertEquals(TileStatus.ON, c.status(TileId.LOCATION))
        assertEquals(TileStatus.OFF, c.status(TileId.AIRPLANE))
        assertEquals(TileStatus.OFF, c.status(TileId.DND))
        assertEquals(TileStatus.ON, c.status(TileId.AUTO_ROTATE))
        assertNull(c.state.value.battery)
        assertNull(c.state.value.now)
    }

    @Test fun startCollectsFlashlightBatteryClockAndCustomization() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        c.start(); runCurrent()
        assertEquals(TileStatus.OFF, c.status(TileId.FLASHLIGHT))
        assertEquals(80, c.state.value.battery?.levelPercent)
        assertNotNull(c.state.value.now)
        rig.custom.setSlots(TileLayout.setEnabled(Customization.default().slots, TileId.WIFI, false)); runCurrent()
        assertFalse(c.state.value.tiles.any { it.id == TileId.WIFI })
        rig.custom.setAccent(AccentColor.GREEN); rig.custom.setPanelAlpha(0.7f); runCurrent()
        assertEquals(AccentColor.GREEN, c.state.value.accent)
        assertEquals(0.7f, c.state.value.panelAlpha, 0.001f)
    }

    @Test fun systemChangeEventsRefreshTheTiles() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        c.start(); runCurrent()
        rig.network.snap = net(wifi = ToggleState.OFF); rig.network.events.tryEmit(Unit); runCurrent()
        assertEquals(TileStatus.OFF, c.status(TileId.WIFI))
        rig.location.value = false; rig.location.events.tryEmit(Unit); runCurrent()
        assertEquals(TileStatus.OFF, c.status(TileId.LOCATION))
    }

    @Test fun stopEndsObservation() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        c.start(); runCurrent(); c.stop()
        rig.network.snap = net(wifi = ToggleState.OFF); rig.network.events.tryEmit(Unit); runCurrent()
        assertEquals(TileStatus.ON, c.status(TileId.WIFI))
        c.refresh() // an explicit refresh still reads the real state
        assertEquals(TileStatus.OFF, c.status(TileId.WIFI))
    }

    @Test fun customizedOrderIsRespected() = runTest {
        val rig = Rig(custom = CCCustomization(Customization.default().copy(
            slots = TileLayout.moveUp(TileLayout.default(), TileId.BLUETOOTH)
        )))
        val c = rig.controller(backgroundScope)
        c.start(); runCurrent()
        assertEquals(TileId.BLUETOOTH, c.state.value.tiles.first().id)
    }

    // ---------------- tiles Android only lets us open ----------------
    @Test fun wifiLocationAndAirplaneOpenTheirSystemScreens() = runTest {
        val c = Rig().controller(backgroundScope)
        assertEquals(TileEffect.Launch(SystemScreen.WIFI_PANEL), c.onTileClick(TileId.WIFI))
        assertEquals(TileEffect.Launch(SystemScreen.LOCATION_SETTINGS), c.onTileClick(TileId.LOCATION))
        assertEquals(TileEffect.Launch(SystemScreen.AIRPLANE_SETTINGS), c.onTileClick(TileId.AIRPLANE))
    }

    @Test fun bluetoothClickDependsOnStateAndHost() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.RequestBluetoothEnable, c.onTileClick(TileId.BLUETOOTH))          // OFF
        rig.network.snap = net(bt = ToggleState.ON)
        assertEquals(TileEffect.Launch(SystemScreen.BLUETOOTH_SETTINGS), c.onTileClick(TileId.BLUETOOTH))
        rig.network.snap = net(bt = ToggleState.PERMISSION_REQUIRED)
        assertEquals(TileEffect.RequestBluetoothPermission, c.onTileClick(TileId.BLUETOOTH))
        rig.network.snap = net(bt = null)
        assertEquals(TileEffect.Rejected(ActionError.UNSUPPORTED), c.onTileClick(TileId.BLUETOOTH))
        rig.network.snap = net(bt = ToggleState.OFF)
        val overlay = rig.controller(backgroundScope, supportsDialogs = false)               // overlay cannot show dialogs
        assertEquals(TileEffect.Launch(SystemScreen.BLUETOOTH_SETTINGS), overlay.onTileClick(TileId.BLUETOOTH))
    }

    @Test fun bluetoothPermissionResultReReadsAndReportsDenial() = runTest {
        val rig = Rig(network = CCNetwork(net(bt = ToggleState.PERMISSION_REQUIRED)))
        val c = rig.controller(backgroundScope)
        assertEquals(TileStatus.PERMISSION_REQUIRED, c.status(TileId.BLUETOOTH))
        rig.network.snap = net(bt = ToggleState.OFF) // what the system reports after the grant
        c.onBluetoothPermissionResult(true)
        assertEquals(TileStatus.OFF, c.status(TileId.BLUETOOTH))
        assertNull(c.state.value.error)
        c.onBluetoothPermissionResult(false)
        assertEquals(ActionError.PERMISSION_REQUIRED, c.state.value.error)
    }

    // ---------------- flashlight: accepted is not confirmed ----------------
    @Test fun acceptedTorchRequestChangesNothingUntilTheCallbackConfirms() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        c.start(); runCurrent()
        assertEquals(TileEffect.None, c.onTileClick(TileId.FLASHLIGHT))
        assertEquals(true, rig.flash.last)
        assertEquals(TileStatus.OFF, c.status(TileId.FLASHLIGHT)) // accepted != on
        rig.flash.s.value = FlashlightState.ON; runCurrent()      // TorchCallback confirms
        assertEquals(TileStatus.ON, c.status(TileId.FLASHLIGHT))
        c.onTileClick(TileId.FLASHLIGHT)
        assertEquals(false, rig.flash.last)
    }

    @Test fun rejectedTorchRequestIsReportedAndUnknownStateNeverCallsTheCamera() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.Rejected(ActionError.FAILED), c.onTileClick(TileId.FLASHLIGHT)) // not started: state unknown
        assertEquals(0, rig.flash.calls)
        c.start(); runCurrent()
        rig.flash.result = RequestResult.Rejected(ActionError.FAILED)
        assertEquals(TileEffect.Rejected(ActionError.FAILED), c.onTileClick(TileId.FLASHLIGHT))
        assertEquals(ActionError.FAILED, c.state.value.error)
        rig.flash.s.value = FlashlightState.UNAVAILABLE; runCurrent()
        assertEquals(TileEffect.Rejected(ActionError.UNSUPPORTED), c.onTileClick(TileId.FLASHLIGHT))
    }

    // ---------------- DND ----------------
    @Test fun dndToggleWithAccessSendsARequestButDoesNotChangeTheShownState() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.None, c.onTileClick(TileId.DND))
        assertEquals(1, rig.sound.dndCalls)
        assertEquals(true, rig.sound.lastDnd)
        assertEquals(TileStatus.OFF, c.status(TileId.DND)) // only a real system read changes it
    }

    @Test fun dndWithoutOrUnknownAccessOpensTheAccessScreenAndNeverCallsTheSystem() = runTest {
        val rig = Rig(sound = CCSound(snd(dnd = DndState(PolicyAccess.NOT_GRANTED, DndFilter.ALL))))
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.Launch(SystemScreen.DND_ACCESS), c.onTileClick(TileId.DND))
        rig.sound.snap = snd(dnd = DndState(PolicyAccess.UNKNOWN, DndFilter.ALL))
        assertEquals(TileEffect.Launch(SystemScreen.DND_ACCESS), c.onTileClick(TileId.DND))
        assertEquals(0, rig.sound.dndCalls)
    }

    @Test fun unknownDndStateIsUnknownNotOffAndCannotBeToggled() = runTest {
        val rig = Rig(sound = CCSound(snd(dnd = DndState(PolicyAccess.GRANTED, DndFilter.UNKNOWN))))
        val c = rig.controller(backgroundScope)
        assertEquals(TileStatus.UNKNOWN, c.status(TileId.DND))
        assertEquals(TileEffect.Rejected(ActionError.FAILED), c.onTileClick(TileId.DND))
        assertEquals(0, rig.sound.dndCalls)
    }

    @Test fun rejectedDndRequestIsReported() = runTest {
        val rig = Rig()
        rig.sound.dndResult = RequestResult.Rejected(ActionError.PERMISSION_REQUIRED)
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.Rejected(ActionError.PERMISSION_REQUIRED), c.onTileClick(TileId.DND))
        assertEquals(ActionError.PERMISSION_REQUIRED, c.state.value.error)
    }

    // ---------------- auto-rotate ----------------
    @Test fun autoRotateNeedsTheWriteSettingsGrant() = runTest {
        val rig = Rig(display = CCDisplay(dsp(canWrite = false)))
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.Launch(SystemScreen.WRITE_SETTINGS), c.onTileClick(TileId.AUTO_ROTATE))
        assertEquals(0, rig.display.rotateCalls)
    }

    @Test fun autoRotateTogglesAndShowsTheReReadValue() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.None, c.onTileClick(TileId.AUTO_ROTATE))
        assertEquals(false, rig.display.lastRotate)
        assertEquals(TileStatus.OFF, c.status(TileId.AUTO_ROTATE))
    }

    @Test fun autoRotateFailureIsReportedAndKeepsTheRealState() = runTest {
        val rig = Rig()
        rig.display.rotateResult = ActionResult.Failure(ActionError.FAILED)
        val c = rig.controller(backgroundScope)
        assertEquals(TileEffect.Rejected(ActionError.FAILED), c.onTileClick(TileId.AUTO_ROTATE))
        assertEquals(TileStatus.ON, c.status(TileId.AUTO_ROTATE))
    }

    @Test fun unreadableAutoRotateIsUnknownAndNotToggled() = runTest {
        val rig = Rig(display = CCDisplay(dsp(autoRotate = null)))
        val c = rig.controller(backgroundScope)
        assertEquals(TileStatus.UNKNOWN, c.status(TileId.AUTO_ROTATE))
        assertEquals(TileEffect.Rejected(ActionError.FAILED), c.onTileClick(TileId.AUTO_ROTATE))
        assertEquals(0, rig.display.rotateCalls)
    }

    // ---------------- brightness and volume ----------------
    @Test fun brightnessWithoutPermissionNeverCallsTheSystem() = runTest {
        val rig = Rig(display = CCDisplay(dsp(canWrite = false)))
        val c = rig.controller(backgroundScope)
        c.setBrightness(200)
        assertEquals(0, rig.display.brightnessCalls)
        assertEquals(ActionError.PERMISSION_REQUIRED, c.state.value.error)
        assertEquals(100, c.state.value.brightness)
    }

    @Test fun brightnessSuccessShowsTheReReadValueAndFailureKeepsTheRealOne() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        c.setBrightness(200)
        assertNull(c.state.value.error)
        assertEquals(200, c.state.value.brightness)
        rig.display.brightnessResult = ActionResult.Failure(ActionError.FAILED)
        c.setBrightness(50)
        assertEquals(ActionError.FAILED, c.state.value.error)
        assertEquals(200, c.state.value.brightness)
        c.clearError()
        assertNull(c.state.value.error)
    }

    @Test fun volumeShowsOnlyMediaAndRingWithTheRealRange() = runTest {
        val c = Rig().controller(backgroundScope)
        assertEquals(listOf(VolumeStream.MEDIA, VolumeStream.RING), c.state.value.volumes.map { it.stream })
        assertEquals(15, c.state.value.volumes.first().max)
    }

    @Test fun volumeSuccessAndFailure() = runTest {
        val rig = Rig()
        val c = rig.controller(backgroundScope)
        c.setVolume(VolumeStream.MEDIA, 9)
        assertEquals(9, c.state.value.volumes.first { it.stream == VolumeStream.MEDIA }.current)
        rig.sound.volumeResult = ActionResult.Failure(ActionError.PERMISSION_REQUIRED)
        c.setVolume(VolumeStream.MEDIA, 12)
        assertEquals(ActionError.PERMISSION_REQUIRED, c.state.value.error)
        assertEquals(9, c.state.value.volumes.first { it.stream == VolumeStream.MEDIA }.current)
    }

    @Test fun unknownVolumeAvailabilityIsPassedThroughNotTreatedAsFixed() = runTest {
        val c = Rig(sound = CCSound(snd(availability = VolumeAvailability.UNKNOWN))).controller(backgroundScope)
        assertEquals(VolumeAvailability.UNKNOWN, c.state.value.volumeAvailability)
    }
}

class TileStatesTests {
    private val n = net()
    private val s = snd()
    private val d = dsp()
    private fun of(id: TileId, network: NetworkSnapshot = n, flash: FlashlightState? = FlashlightState.OFF, loc: Boolean? = true) =
        TileStates.of(id, network, s, d, flash, loc).status

    @Test fun wifiAndBluetoothMapping() {
        assertEquals(TileStatus.ON, of(TileId.WIFI, net(wifi = ToggleState.TURNING_ON)))
        assertEquals(TileStatus.OFF, of(TileId.WIFI, net(wifi = ToggleState.TURNING_OFF)))
        assertEquals(TileStatus.UNAVAILABLE, of(TileId.WIFI, net(wifi = null)))
        assertEquals(TileStatus.UNKNOWN, of(TileId.WIFI, net(wifi = ToggleState.UNKNOWN)))
        assertEquals(TileStatus.PERMISSION_REQUIRED, of(TileId.BLUETOOTH, net(bt = ToggleState.PERMISSION_REQUIRED)))
    }

    @Test fun flashlightMapping() {
        assertEquals(TileStatus.ON, of(TileId.FLASHLIGHT, flash = FlashlightState.ON))
        assertEquals(TileStatus.UNAVAILABLE, of(TileId.FLASHLIGHT, flash = FlashlightState.UNSUPPORTED))
        assertEquals(TileStatus.UNAVAILABLE, of(TileId.FLASHLIGHT, flash = FlashlightState.UNAVAILABLE))
        assertEquals(TileStatus.UNKNOWN, of(TileId.FLASHLIGHT, flash = FlashlightState.UNKNOWN))
        assertEquals(TileStatus.UNKNOWN, of(TileId.FLASHLIGHT, flash = null))
    }

    @Test fun locationAndAirplaneNeverDefaultToOff() {
        assertEquals(TileStatus.UNKNOWN, of(TileId.LOCATION, loc = null))
        assertEquals(TileStatus.OFF, of(TileId.LOCATION, loc = false))
        assertEquals(TileStatus.UNKNOWN, of(TileId.AIRPLANE, net(airplane = null)))
        assertEquals(TileStatus.ON, of(TileId.AIRPLANE, net(airplane = true)))
    }

    @Test fun visibleTilesFollowOrderAndVisibility() {
        val slots = TileLayout.setEnabled(TileLayout.moveDown(TileLayout.default(), TileId.WIFI), TileId.DND, false)
        val tiles = TileStates.visibleTiles(slots, n, s, d, FlashlightState.OFF, true)
        assertEquals(TileId.BLUETOOTH, tiles.first().id)
        assertEquals(TileId.WIFI, tiles[1].id)
        assertFalse(tiles.any { it.id == TileId.DND })
    }
}
