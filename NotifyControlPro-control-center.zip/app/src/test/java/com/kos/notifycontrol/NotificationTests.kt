package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.ActionError
import com.kos.notifycontrol.domain.model.RequestResult
import com.kos.notifycontrol.domain.notifications.NotificationActions
import com.kos.notifycontrol.domain.notifications.NotificationFilter
import com.kos.notifycontrol.domain.notifications.NotificationItem
import com.kos.notifycontrol.domain.notifications.NotificationStore
import com.kos.notifycontrol.domain.repository.NotificationAccess
import com.kos.notifycontrol.features.notifications.NotificationCenterViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

private fun item(key: String, time: Long, clearable: Boolean = true) =
    NotificationItem(key, "pkg.$key", "App $key", "title $key", "text $key", time, !clearable, clearable)

private class NFActions(var result: RequestResult = RequestResult.Accepted) : NotificationActions {
    val calls = mutableListOf<String>()
    override fun open(key: String): RequestResult { calls += "open:$key"; return result }
    override fun dismiss(key: String): RequestResult { calls += "dismiss:$key"; return result }
    override fun dismissAll(): RequestResult { calls += "dismissAll"; return result }
}

private class NFAccess(var enabled: Boolean) : NotificationAccess { override fun isEnabled() = enabled }

class NotificationStoreTests {
    @Test fun connectedListIsNewestFirstAndDistinct() {
        val s = NotificationStore()
        s.onConnected(listOf(item("a", 1), item("b", 3), item("c", 2), item("b", 3)), NFActions())
        assertEquals(listOf("b", "c", "a"), s.items.value.map { it.key })
        assertTrue(s.connected.value)
        assertNotNull(s.actions)
    }

    @Test fun postedReplacesTheSameKeyAndKeepsTheOrder() {
        val s = NotificationStore()
        s.onConnected(listOf(item("a", 1), item("b", 2)), NFActions())
        s.onPosted(item("a", 5))
        s.onPosted(item("c", 3))
        assertEquals(listOf("a", "c", "b"), s.items.value.map { it.key })
        assertEquals(3, s.items.value.size)
        assertEquals(5L, s.items.value.first().postTime)
    }

    @Test fun removedDropsOnlyThatKey() {
        val s = NotificationStore()
        s.onConnected(listOf(item("a", 1), item("b", 2)), NFActions())
        s.onRemoved("a")
        s.onRemoved("missing")
        assertEquals(listOf("b"), s.items.value.map { it.key })
    }

    @Test fun disconnectClearsTheListInsteadOfKeepingStaleData() {
        val s = NotificationStore()
        s.onConnected(listOf(item("a", 1)), NFActions())
        s.onDisconnected()
        assertTrue(s.items.value.isEmpty())
        assertFalse(s.connected.value)
        assertNull(s.actions)
    }

    @Test fun ownNotificationsAndGroupSummariesAreHidden() {
        assertFalse(NotificationFilter.shouldShow("com.kos.notifycontrol", "com.kos.notifycontrol", false))
        assertFalse(NotificationFilter.shouldShow("other", "com.kos.notifycontrol", true))
        assertTrue(NotificationFilter.shouldShow("other", "com.kos.notifycontrol", false))
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class NotificationCenterViewModelTests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun stateReflectsAccessConnectionAndItems() = runTest {
        val store = NotificationStore()
        val access = NFAccess(false)
        val vm = NotificationCenterViewModel(store, access)
        backgroundScope.launch { vm.state.collect {} }
        runCurrent()
        assertFalse(vm.state.value.accessEnabled)
        assertFalse(vm.state.value.connected)
        access.enabled = true
        vm.refreshAccess(); runCurrent()
        assertTrue(vm.state.value.accessEnabled)
        store.onConnected(listOf(item("a", 1)), NFActions()); runCurrent()
        assertTrue(vm.state.value.connected)
        assertEquals(1, vm.state.value.items.size)
    }

    @Test fun actionsWithoutAConnectedListenerAreReportedNotFaked() = runTest {
        val vm = NotificationCenterViewModel(NotificationStore(), NFAccess(true))
        backgroundScope.launch { vm.state.collect {} }
        vm.dismiss("a"); runCurrent()
        assertEquals(ActionError.FAILED, vm.state.value.error)
        vm.clearError(); runCurrent()
        assertNull(vm.state.value.error)
    }

    @Test fun actionsAreForwardedToTheListener() = runTest {
        val store = NotificationStore()
        val actions = NFActions()
        store.onConnected(listOf(item("a", 1)), actions)
        val vm = NotificationCenterViewModel(store, NFAccess(true))
        backgroundScope.launch { vm.state.collect {} }
        vm.open("a"); vm.dismiss("a"); vm.dismissAll(); runCurrent()
        assertEquals(listOf("open:a", "dismiss:a", "dismissAll"), actions.calls)
        assertNull(vm.state.value.error)
    }

    @Test fun rejectedActionsSurfaceTheirError() = runTest {
        val store = NotificationStore()
        store.onConnected(listOf(item("a", 1)), NFActions(RequestResult.Rejected(ActionError.UNSUPPORTED)))
        val vm = NotificationCenterViewModel(store, NFAccess(true))
        backgroundScope.launch { vm.state.collect {} }
        vm.open("a"); runCurrent()
        assertEquals(ActionError.UNSUPPORTED, vm.state.value.error)
    }
}
