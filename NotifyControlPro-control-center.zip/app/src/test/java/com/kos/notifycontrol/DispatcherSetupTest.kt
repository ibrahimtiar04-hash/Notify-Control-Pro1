package com.kos.notifycontrol

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

/** Guards the assumption every ViewModel test relies on: one scheduler for Main and runTest. */
@OptIn(ExperimentalCoroutinesApi::class)
class DispatcherSetupTest {
    @get:Rule val main = MainDispatcherRule()

    @Test fun runTestSharesSchedulerWithMain() = runTest {
        assertSame(main.scheduler, testScheduler)
    }

    @Test fun mainDelayAdvancesWithTestClock() = runTest {
        var done = false
        launch(Dispatchers.Main) { delay(1_000); done = true }
        runCurrent()
        assertFalse(done)
        advanceTimeBy(1_001)
        runCurrent()
        assertTrue(done)
        assertEquals(1_001L, testScheduler.currentTime)
    }
}
