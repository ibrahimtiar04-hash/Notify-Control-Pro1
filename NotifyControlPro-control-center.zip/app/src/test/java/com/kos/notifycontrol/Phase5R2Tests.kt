package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.ActionResult
import com.kos.notifycontrol.domain.repository.TimerRepository
import com.kos.notifycontrol.domain.tools.TimerLogic
import com.kos.notifycontrol.features.tools.TimerViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

private class R2Timer : TimerRepository {
    var restored = 0
    val end = MutableStateFlow<Long?>(null)
    override val endAtMillis: Flow<Long?> = end
    override suspend fun start(durationMs: Long): ActionResult = ActionResult.Success(0)
    override suspend fun cancel() {}
    override suspend fun restore() { restored++ }
}

class Phase5R2Tests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun timerViewModelNeverRestores_theApplicationIsTheOnlyRestorePoint() {
        val repo = R2Timer()
        TimerViewModel(repo)
        assertEquals(0, repo.restored)
    }

    @Test fun notificationsAllowedRules() {
        assertTrue(TimerLogic.notificationsAllowed(30, true, false))   // pre-13: no runtime permission needed
        assertFalse(TimerLogic.notificationsAllowed(30, false, true))  // notifications disabled in system settings
        assertFalse(TimerLogic.notificationsAllowed(33, true, false))  // 13+: permission denied
        assertTrue(TimerLogic.notificationsAllowed(33, true, true))
        assertFalse(TimerLogic.notificationsAllowed(34, false, true))
    }
}
