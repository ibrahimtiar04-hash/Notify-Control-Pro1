package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class CustomizationTests {
    @Test fun defaultHasEveryTileVisible() {
        val d = TileLayout.default()
        assertEquals(TileId.entries.toList(), d.map { it.id })
        assertTrue(d.all { it.enabled })
        assertEquals(Customization.default().slots, d)
    }

    @Test fun serializeThenParseRoundTrips() {
        val slots = TileLayout.setEnabled(TileLayout.moveUp(TileLayout.default(), TileId.DND), TileId.WIFI, false)
        assertEquals(slots, TileLayout.parse(TileLayout.serialize(slots)))
    }

    @Test fun parseIsDefensive() {
        assertEquals(TileLayout.default(), TileLayout.parse(null))
        assertEquals(TileLayout.default(), TileLayout.parse(""))
        assertEquals(TileLayout.default(), TileLayout.parse("garbage,,:::,NOPE:1"))
        val parsed = TileLayout.parse("BLUETOOTH:0,WIFI:1,WIFI:0,UNKNOWN:1")
        assertEquals(TileSlot(TileId.BLUETOOTH, false), parsed[0])
        assertEquals(TileSlot(TileId.WIFI, true), parsed[1])          // first occurrence wins
        assertEquals(TileId.entries.size, parsed.size)                // missing tiles are appended...
        assertTrue(parsed.drop(2).all { it.enabled })                 // ...and visible
    }

    @Test fun moveUpAndDownRespectTheEdges() {
        val d = TileLayout.default()
        assertEquals(d, TileLayout.moveUp(d, d.first().id))
        assertEquals(d, TileLayout.moveDown(d, d.last().id))
        assertEquals(d[1].id, TileLayout.moveUp(d, d[1].id).first().id)
        assertEquals(d[0].id, TileLayout.moveDown(d, d[0].id)[1].id)
    }

    @Test fun theLastVisibleTileCannotBeHidden() {
        var slots = TileLayout.default()
        TileId.entries.drop(1).forEach { slots = TileLayout.setEnabled(slots, it, false) }
        assertEquals(listOf(TileId.entries.first()), TileLayout.visible(slots))
        assertEquals(slots, TileLayout.setEnabled(slots, TileId.entries.first(), false))
        assertTrue(TileLayout.setEnabled(slots, TileId.WIFI, true).first { it.id == TileId.WIFI }.enabled)
    }

    @Test fun alphaIsClampedAndNanFallsBackToOpaque() {
        assertEquals(0.5f, Customization.clampAlpha(0.1f), 0f)
        assertEquals(1f, Customization.clampAlpha(3f), 0f)
        assertEquals(0.8f, Customization.clampAlpha(0.8f), 0f)
        assertEquals(1f, Customization.clampAlpha(Float.NaN), 0f)
    }

    @Test fun unknownAccentFallsBackToBlue() {
        assertEquals(AccentColor.PURPLE, AccentColor.fromName("PURPLE"))
        assertEquals(AccentColor.BLUE, AccentColor.fromName("nope"))
        assertEquals(AccentColor.BLUE, AccentColor.fromName(null))
    }
}
