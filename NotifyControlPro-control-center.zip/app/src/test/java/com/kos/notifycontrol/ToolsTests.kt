package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.*
import com.kos.notifycontrol.domain.repository.FlashlightRepository
import com.kos.notifycontrol.domain.repository.RecorderRepository
import com.kos.notifycontrol.domain.repository.TimerRepository
import com.kos.notifycontrol.domain.tools.*
import com.kos.notifycontrol.features.tools.*
import java.util.Locale
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

private fun calc(e: String) = CalculatorEngine.evaluate(e)
private fun value(e: String) = (calc(e) as CalcResult.Value).text

class CalculatorEngineTests {
    @Test fun precedenceAndParentheses() {
        assertEquals("14", value("2+3×4"))
        assertEquals("20", value("(2+3)×4"))
        assertEquals("2.5", value("10÷4"))
        assertEquals("-3", value("-5+2"))
    }
    @Test fun exactDecimalsAndPercent() {
        assertEquals("0.3", value("0.1+0.2"))
        assertEquals("1", value(".5+.5"))
        assertEquals("0.5", value("50%"))
        assertEquals("200.1", value("200+10%"))
        assertEquals("0.3333333333333333", value("1÷3"))
    }
    @Test fun divisionByZeroIsAnError() {
        assertEquals(CalcResult.Error(CalcError.DIVISION_BY_ZERO), calc("5÷0"))
        assertEquals(CalcResult.Error(CalcError.DIVISION_BY_ZERO), calc("1÷(2-2)"))
    }
    @Test fun malformedExpressionsAreSyntaxErrors() {
        listOf("", "2+", "(2", "2..3", "1.5.2", "×3", "2++3", ".", "2)").forEach {
            assertEquals("input: $it", CalcResult.Error(CalcError.SYNTAX), calc(it))
        }
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class CalculatorViewModelTests {
    @get:Rule val main = MainDispatcherRule()

    private fun CalculatorViewModel.type(s: String) = s.forEach { onKey(it) }

    @Test fun typesAndEvaluates() {
        val vm = CalculatorViewModel()
        vm.type("2+3×4"); vm.equals()
        assertEquals("14", vm.state.value.result)
        assertEquals("2+3×4", vm.state.value.expression)
    }
    @Test fun operatorContinuesFromResultDigitStartsFresh() {
        val vm = CalculatorViewModel()
        vm.type("6÷3"); vm.equals()
        vm.onKey('+'); assertEquals("2+", vm.state.value.expression); assertNull(vm.state.value.result)
        vm.type("1"); vm.equals(); assertEquals("3", vm.state.value.result)
        vm.onKey('7'); assertEquals("7", vm.state.value.expression)
    }
    @Test fun errorIsReportedAndClearedByTyping() {
        val vm = CalculatorViewModel()
        vm.type("1÷0"); vm.equals()
        assertEquals(CalcError.DIVISION_BY_ZERO, vm.state.value.error)
        assertNull(vm.state.value.result)
        vm.onKey('5'); assertNull(vm.state.value.error)
    }
    @Test fun backspaceClearAndLengthLimit() {
        val vm = CalculatorViewModel()
        vm.type("123"); vm.backspace(); assertEquals("12", vm.state.value.expression)
        vm.clear(); assertEquals("", vm.state.value.expression)
        repeat(80) { vm.onKey('1') }
        assertEquals(60, vm.state.value.expression.length)
    }
    @Test fun equalsOnEmptyDoesNothing() {
        val vm = CalculatorViewModel(); vm.equals()
        assertEquals(CalculatorUi(), vm.state.value)
    }
}

class TimerAndClockTests {
    @Test fun statusFromEndTime() {
        assertEquals(TimerStatus.IDLE, TimerLogic.status(null, 100))
        assertEquals(TimerStatus.RUNNING, TimerLogic.status(200, 100))
        assertEquals(TimerStatus.FINISHED, TimerLogic.status(100, 100))
        assertEquals(TimerStatus.FINISHED, TimerLogic.status(50, 100))
        assertEquals(0L, TimerLogic.remainingMillis(50, 100))
        assertEquals(100L, TimerLogic.remainingMillis(200, 100))
    }
    @Test fun parseDurationValidation() {
        assertEquals(90_000L, TimerLogic.parseDuration("1", "30"))
        assertEquals(5_000L, TimerLogic.parseDuration("", "5"))
        assertEquals(120_000L, TimerLogic.parseDuration("2", ""))
        assertEquals(90_000L, TimerLogic.parseDuration("0", "90"))
        assertNull(TimerLogic.parseDuration("", ""))
        assertNull(TimerLogic.parseDuration("0", "0"))
        assertNull(TimerLogic.parseDuration("a", "5"))
        assertNull(TimerLogic.parseDuration("1441", "0"))
        assertEquals(TimerLogic.MAX_MILLIS, TimerLogic.parseDuration("1440", "0"))
    }
    @Test fun formatClockValues() {
        val us = Locale.US
        assertEquals("01:01", formatClock(61_000, false, us))
        assertEquals("1:01:01", formatClock(3_661_000, false, us))
        assertEquals("00:01", formatClock(500, false, us)) // countdown rounds up
        assertEquals("00:00", formatClock(0, false, us))
        assertEquals("00:00", formatClock(-5, false, us))
        assertEquals("00:01.23", formatClock(1_230, true, us))
    }
}

private class FakeTime(var now: Long = 0) : TimeSource { override fun elapsedMillis() = now }

class StopwatchTests {
    @Test fun accumulatesAcrossPauses() {
        val t = FakeTime(); val w = Stopwatch(t)
        w.start(); t.now = 1_000; assertEquals(1_000L, w.elapsedMillis())
        w.pause(); t.now = 5_000; assertEquals(1_000L, w.elapsedMillis())
        w.start(); t.now = 6_500; assertEquals(2_500L, w.elapsedMillis())
    }
    @Test fun doubleStartKeepsOriginalStart() {
        val t = FakeTime(); val w = Stopwatch(t)
        w.start(); t.now = 500; w.start(); t.now = 1_000
        assertEquals(1_000L, w.elapsedMillis())
    }
    @Test fun lapsOnlyWhileRunningAndResetClears() {
        val t = FakeTime(); val w = Stopwatch(t)
        assertFalse(w.lap())
        w.start(); t.now = 300; assertTrue(w.lap()); t.now = 700; w.lap()
        assertEquals(listOf(300L, 700L), w.laps)
        w.reset()
        assertEquals(0L, w.elapsedMillis()); assertTrue(w.laps.isEmpty()); assertFalse(w.isRunning)
    }
    @Test fun viewModelPublishesState() {
        val t = FakeTime(); val vm = StopwatchViewModel(t)
        vm.start(); assertTrue(vm.state.value.running)
        t.now = 400; vm.lap(); assertEquals(listOf(400L), vm.state.value.laps)
        vm.pause(); assertFalse(vm.state.value.running)
        vm.reset(); assertEquals(StopwatchUi(), vm.state.value)
    }
}

private class FakeTimerRepo(var result: ActionResult = ActionResult.Success(0)) : TimerRepository {
    val end = MutableStateFlow<Long?>(null)
    var startedWith: Long? = null
    var cancelled = 0
    override val endAtMillis: Flow<Long?> = end.asStateFlow()
    override suspend fun start(durationMs: Long): ActionResult { startedWith = durationMs; return result }
    override suspend fun cancel() { cancelled++ }
    var restored = 0
    override suspend fun restore() { restored++ }
}

private class FakeRecorder : RecorderRepository {
    var startResult: ActionResult = ActionResult.Success(1)
    var stopResult: ActionResult = ActionResult.Success(0)
    val files = mutableListOf<Recording>()
    var stopCalls = 0
    override fun start() = startResult
    override fun stop(): ActionResult { stopCalls++; return stopResult }
    override fun list(): List<Recording> = files.toList()
    override fun delete(name: String) = files.removeAll { it.name == name }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ToolViewModelTests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun timerInvalidInputNeverCallsRepository() {
        val repo = FakeTimerRepo()
        val vm = TimerViewModel(repo)
        vm.start("", "")
        assertTrue(vm.invalidInput.value)
        assertNull(repo.startedWith)
    }

    @Test fun timerStartPassesRealDurationAndCancelCallsRepository() {
        val repo = FakeTimerRepo()
        val vm = TimerViewModel(repo)
        vm.start("1", "30")
        assertFalse(vm.invalidInput.value)
        assertEquals(90_000L, repo.startedWith)
        vm.cancel()
        assertEquals(1, repo.cancelled)
    }

    @Test fun timerStartFailureIsReported() {
        val vm = TimerViewModel(FakeTimerRepo(ActionResult.Failure(ActionError.PERMISSION_REQUIRED)))
        vm.start("0", "10")
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.error.value)
    }

    @Test fun recorderStartStopRefreshesList() {
        val repo = FakeRecorder()
        val t = FakeTime(1_000)
        val vm = RecorderViewModel(repo, t)
        vm.start()
        assertTrue(vm.state.value.recording)
        t.now = 3_500
        assertEquals(2_500L, vm.elapsedMillis())
        repo.files.add(Recording("a.m4a", "/x/a.m4a", 10, 1))
        vm.stop()
        assertFalse(vm.state.value.recording)
        assertEquals(1, vm.state.value.recordings.size)
        assertEquals(0L, vm.elapsedMillis())
    }

    @Test fun recorderStartFailureDoesNotShowRecording() {
        val repo = FakeRecorder().apply { startResult = ActionResult.Failure(ActionError.PERMISSION_REQUIRED) }
        val vm = RecorderViewModel(repo, FakeTime())
        vm.start()
        assertFalse(vm.state.value.recording)
        assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
        vm.clearError(); assertNull(vm.state.value.error)
        vm.onMicPermissionDenied(); assertEquals(ActionError.PERMISSION_REQUIRED, vm.state.value.error)
    }

    @Test fun recorderStopFailureIsReportedAndRecordingEnds() {
        val repo = FakeRecorder().apply { stopResult = ActionResult.Failure(ActionError.FAILED) }
        val vm = RecorderViewModel(repo, FakeTime())
        vm.start(); vm.stop()
        assertFalse(vm.state.value.recording)
        assertEquals(ActionError.FAILED, vm.state.value.error)
    }

    @Test fun stopIfRecordingOnlyActsWhenRecording() {
        val repo = FakeRecorder()
        val vm = RecorderViewModel(repo, FakeTime())
        vm.stopIfRecording()
        assertEquals(0, repo.stopCalls)
        vm.start(); vm.stopIfRecording()
        assertEquals(1, repo.stopCalls)
    }

    @Test fun recorderDeleteRefreshes() {
        val repo = FakeRecorder().apply { files.add(Recording("a.m4a", "/x/a.m4a", 10, 1)) }
        val vm = RecorderViewModel(repo, FakeTime())
        assertEquals(1, vm.state.value.recordings.size)
        vm.delete("a.m4a")
        assertTrue(vm.state.value.recordings.isEmpty())
    }
}
