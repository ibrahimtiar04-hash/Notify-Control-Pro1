package com.kos.notifycontrol

import com.kos.notifycontrol.domain.model.ThemeMode
import com.kos.notifycontrol.domain.repository.SettingsRepository
import com.kos.notifycontrol.features.settings.SettingsViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

private class FakeSettings : SettingsRepository {
    val state = MutableStateFlow(ThemeMode.SYSTEM)
    override val themeMode: Flow<ThemeMode> = state
    override suspend fun setThemeMode(mode: ThemeMode) { state.value = mode }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ViewModelTests {
    @get:Rule val main = MainDispatcherRule()

    @Test fun settingsViewModelStartsWithStoredTheme() {
        val repo = FakeSettings().apply { state.value = ThemeMode.LIGHT }
        assertEquals(ThemeMode.LIGHT, SettingsViewModel(repo).themeMode.value)
    }

    @Test fun settingsViewModelWritesSelectedTheme() = runTest {
        val repo = FakeSettings()
        val vm = SettingsViewModel(repo)
        vm.setTheme(ThemeMode.DARK)
        assertEquals(ThemeMode.DARK, repo.state.value)
        assertEquals(ThemeMode.DARK, vm.themeMode.value)
    }
}
