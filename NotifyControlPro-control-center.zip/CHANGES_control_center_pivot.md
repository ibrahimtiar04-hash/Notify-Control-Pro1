# NotifyControlPro: pivot to Control Center & Notification Manager

Status: NOT built and NOT run by the author (the authoring environment has no Android SDK, Gradle or network).
No build or test result is claimed. gradle-wrapper.jar is still missing: generate it with
`gradle wrapper --gradle-version 8.11.1`, then `./gradlew testDebugUnitTest assembleDebug`.
minSdk is now 29 (Android 10); compile/target SDK 36 (Android 16).

## 1. Project inspection: keep / rebuild / remove
KEPT (working, reused as-is): Hilt/DataStore/theme/settings plumbing, repositories for Wi-Fi/Bluetooth/airplane
(NetworkRepository), volume + Do Not Disturb (SoundRepository), brightness (DisplayRepository), torch
(FlashlightRepository + TorchResolver), battery, clock; tools (calculator, timer + TimerCoordinator, stopwatch, voice recorder
+ RecordingStore); DndUi, VolumeAvailability, RequestResult conventions; Gradle/CI files.
REBUILT: navigation (5 destinations: Control, Notifications, Tools, Customize, Settings), theme (accent color), MainActivity,
DisplayRepository (+ auto-rotate write), manifest, strings.
REMOVED (did not serve a control center): Dashboard (device info / storage / battery cards), Display screen, Sound screen,
Network screen, flashlight tool screen (now a tile), StorageRepository, DeviceInfoRepository, Reading, their tests, 81 unused strings.

## 2. What was built (requested items)
1-2. Quick control panel: ControlCenterContent (time/date, 3-column tile grid, brightness + volume sliders, battery card),
     ControlCenterController shared by the app screen and the overlay.
3. Floating panel: FloatingPanelService (foreground service + overlay ComposeView). A small handle sits just below the status bar;
   drag it down or tap it to open the panel over other apps; scrim tap / close button closes it. Stop from the switch, the
   notification action, or the Quick Settings tile.
4. Tiles: Wi-Fi, Bluetooth, flashlight, location, airplane mode, Do Not Disturb, auto-rotate.
5. Brightness (system brightness, needs WRITE_SETTINGS), volume (media + ring, real min/max), battery (level, charging).
6-7. Notification center: NotifyListenerService + in-memory NotificationStore; open (PendingIntent, fallback launch intent),
     dismiss (clearable only), clear all, manage (the app's system notification settings).
8. Quick Settings tile (FloatingPanelTileService) toggling the floating panel; Android 13+ "add tile" request button.
9. Customization: show/hide + order (up/down) of tiles, 6 accent colors, panel opacity 50-100 %, reset; persisted in DataStore.
10. Arabic RTL + English strings, dark/light/system theme, accessibility descriptions on tiles/handle.

## 3. How each tile behaves (Android limits respected)
- Flashlight: direct toggle (CameraManager). Accepted != confirmed: the tile changes only when TorchCallback reports it.
- Auto-rotate: direct toggle, needs the WRITE_SETTINGS grant (otherwise the grant screen opens); verified by read-back.
- Do Not Disturb: direct toggle (Priority only) if Notification Policy Access is granted; otherwise opens that grant screen.
  An unreadable state is UNKNOWN (never OFF) and the toggle is disabled.
- Bluetooth: OFF -> system "turn on" dialog (BLUETOOTH_CONNECT on Android 12+); otherwise Bluetooth settings.
  In the overlay (cannot show dialogs) it always opens Bluetooth settings.
- Wi-Fi: opens the system Wi-Fi panel (Android blocks direct toggling). Airplane mode and Location: open their settings
  (no public API to change them). State of all of them is read from the system.
- Anything unreadable is UNKNOWN / UNAVAILABLE / "permission required"; no default values.

## 4. Permissions (requested when needed)
WRITE_SETTINGS (brightness, auto-rotate), notification access (special, via settings), SYSTEM_ALERT_WINDOW (floating panel),
notification-policy access (DND), BLUETOOTH_CONNECT (enable dialog), POST_NOTIFICATIONS (timer + foreground notification),
RECORD_AUDIO (recorder), FOREGROUND_SERVICE + FOREGROUND_SERVICE_SPECIAL_USE (floating panel), ACCESS_NETWORK/WIFI_STATE.
No QUERY_ALL_PACKAGES (a launcher <queries> intent is used).

## 5. Honest limits
- This app does NOT replace the system notification shade or Quick Settings. The handle is below the status bar, so the system
  pull-down area stays the system's. The notification center shows what the listener service is given and only when the user
  enabled notification access.
- Notification contents are kept in memory only (never saved, logged or sent). Android 15+ may redact sensitive notifications
  (for example one-time codes) for listener apps.
- Only clearable notifications can be dismissed; ongoing ones cannot.
- The floating panel is not restarted after a reboot or a process kill (the user turns it on again).
- Play Store: SYSTEM_ALERT_WINDOW, notification listener and the special-use foreground service need declarations/justification.

## 6. Assumptions that need a real build/device to confirm
- LocationManager.PROVIDERS_CHANGED_ACTION is delivered when the location master switch changes (Android 10-16).
- ActivityOptions.setPendingIntentBackgroundActivityStartMode (API 34) lets opening a notification from the overlay work.
- TileService.onClick may start the foreground service (user-interaction exemption).
- StatusBarManager.requestAddTileService behaviour per OEM; vector icon paths render as intended.
- The overlay ComposeView hosted in a Service (manual Lifecycle/SavedState/ViewModelStore owners) behaves on all versions.

## 7. Tests: 111 written, none run
New: ControlCenterTests (27: tile states from real snapshots, start/stop observation, click effects, accepted != confirmed,
DND unknown/permission, auto-rotate, brightness/volume), CustomizationTests (7), NotificationTests (9).
Kept/adapted: timer coordinator, torch resolver, DND UI, volume availability, recording store, network mappers, battery parser, settings.
Android-framework code (listener service, overlay service, tile service, repositories) is not unit-tested.

## 8. Status per feature
IMPLEMENTED BUT NOT TESTED: all items above.
REQUIRES USER PERMISSION: notification access, overlay, write settings, DND access, Bluetooth connect.
BLOCKED BY ANDROID: direct Wi-Fi / airplane / location / mobile data / hotspot toggles; replacing the system shade.
NOT IMPLEMENTED: screen recording, recent apps, drag-and-drop reordering (up/down buttons instead), snooze, per-app grouping,
auto-start of the floating panel at boot, Google Play Billing / Premium.
