# NOTIFY CONTROL PRO (com.kos.notifycontrol)

Control Center & Notification Manager for Android 10-16 (Kotlin, Jetpack Compose, Material 3, Hilt, DataStore). No WebView.
Rule: no fake data. Unavailable -> "غير متاح"; needs permission -> "يتطلب إذناً".

See CHANGES_control_center_pivot.md for what exists, what Android blocks, and what is unverified.
Status: written, NOT yet built or tested by the author.

## Build
JDK 17, Gradle 8.11.1, AGP 8.9.1, Kotlin 2.0.21, compile/target SDK 36, minSdk 29.
`gradle/wrapper/gradle-wrapper.jar` is a binary that could not be generated offline:
run `gradle wrapper --gradle-version 8.11.1` once, then `./gradlew testDebugUnitTest assembleDebug`.
Release: set GitHub Secrets KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD and run the "Android Release" workflow.
